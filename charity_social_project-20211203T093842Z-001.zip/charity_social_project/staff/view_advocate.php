<div>	<?php include_once("../shares/db/mydatabase.inc");
include_once("top.php");
  ?>
	 </div>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: brown;
    color: white;
    height: 40px;
				   text-align: center;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}
	td{
		color: white;
		text-align: center;
	}
	body{
			background-image: url(../temp/images/law5.jpg);
			 background-size: cover;
		}

    </style>
 </head>
	<!--user--->
<body>
<?php
if(isset($_GET['id'])){
	
	$id=$_GET['id'];
	$m=$_GET['mode'];
	if($m=="app"){
		$sql="update login_reg set status='1' where username='$id'";
		setDatas($sql);
		nextpage("app_advocate.php");
		
	}
	else
	{
		$sql="update login_reg set status='0' where username='$id'";
		setDatas($sql);
	}
}
?>
	
	

	<?php

$sql="select advocate_registration.*,login_reg.* from advocate_registration join login_reg on advocate_registration.email=login_reg.username where login_reg.status='0'";
					$tbl=getDatas($sql);
if($tbl==null){
	echo "<div style='position:relative;top:250px;color:blue;left:620px;'>No New Registrations.........</div>";
}
else
{
?>
										<h1 style="position:relative;left:520px;top:120px;">NEW ADVOCATE REGISTRATION</h1>

				<table border="1" style="position:relative;width:1400px;left:90px;top:150px;">
					<thead>
						<tr>
							<th>Profile</th>
							<th>Advocate Name</th>
                            <th>Gender</th>
                            <th>Specialization</th>
                            <th>Officename</th>
                                                     
                            <th>State</th>
							<th>District</th>
							 <th>Palce</th>
							 <th>Phone Number</th>
							 <th>Email</th>
							 
                            
							<th colspan="2">Approval</th>
                         
                         
				       </tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr >
						<td><img src="<?php echo $tbl[$i][12];?>"  height="50" width="50"></td>
						<td><?php echo $tbl[$i][1];?></td>
						<td><?php echo $tbl[$i][2];?></td>
						<td><?php echo $tbl[$i][3];?></td>
						<td><?php echo $tbl[$i][4];?></td>
						<td><?php echo $tbl[$i][6];?></td>
						<td><?php echo $tbl[$i][7];?></td>
							<td><?php echo $tbl[$i][5];?></td>
						<td><?php echo $tbl[$i][11];?></td>
						<td><?php echo $tbl[$i][10];?></td>
						
						<td><a href="?id=<?php echo $tbl[$i][10];?>&mode=app">Approved</a></td>
						<td><a href="?id=<?php echo $tbl[$i][10];?>&mode=rej">Rejected</a></td>
						
						</tr>
						
					<?php 
					}
}
					?>
					</tbody>
				
				</table>
		
	<!--user-->
</body>