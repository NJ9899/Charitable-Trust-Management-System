<?php session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");
?>
<?php include("top.php"); ?>
<head>
<style>
        
input[type=text],input[type=email],input[type=date] ,input[type=password],select,textarea{
                border: 2px solid;
             border-radius: 4px;
             width: 100%;
           
             
            }
            label{
                color: green;
                font-size: 20px;
            }
            table{
                padding-bottom:1em;
                width: 500px;
                height: 200px;
            }
			
            .div1 {
    border-radius: 5px;
    background-color: #f2f2f2;
    margin: auto;
   padding: 30px;
    width:50%;
}
input[type=submit] {
    background-color: tomato;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
    width:100px;
}

input[type=submit]:hover{
    background-color: #ac2925;
}


    </style>
 </head>
 <?php
 
 
 $id=$_GET['a'];
 echo $id;
 ?>

     
                                  

 <h3 style="position: relative;top:130px;left:320px">DELIVERY STATUS</h3>
    	<div class="div1"  style="position: relative;top:160px;left:20px;">
        <form action="" method="post">
           
            <table style="position: relative;left:10px;top:30px">
			 <tr>
                    <td>
                        <label>  OREDER ID</label>
                    </td>
                    <td>
                        <input type="text" name="wid" value="<?php echo $id;?>" readonly />
                      </td>
                </tr>
           <tr><td></td></tr>
                
                 <tr>
                    <td>
                        <label>STATUS</label>
                    </td>
                    <td>
                       <textarea name="reply"></textarea>
                      </td>
                </tr>
           <tr><td></td></tr>
                 
 <tr><td></td></tr>
         
               
				<tr><td></td><td><input type="submit" value="Update"></td></tr>
            </table>
            
            
        </form></div>
		<?php
		if(isset($_POST['wid']))
		{
			
			$id=$_POST['wid'];
			
			$reply=$_POST['reply'];
			
			$sql="update tbl_order set status='$reply' where order_id='$id'";
			setDatas($sql);
			msgbox('Success');
			
			
		}
		
		
		?>