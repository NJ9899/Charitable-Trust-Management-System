<?
include("top.php");
?>
<!-- banner -->
	<div class="w3ls-banner">
		<!-- banner-text -->
		<div class="slider">
			<div class="callbacks_container">
				<ul class="rslides callbacks callbacks1" id="slider4">
					<li>
						<div class="w3layouts-banner-top">

							<div class="container">
								<div class="agileits-banner-info">
								<h4>lend </h4>
									<h3>a helping hand</h3>
										<p>Welcome to our website</p>
									<div class="agileits_w3layouts_more menu__item">
				<a href="#" class="menu__link" data-toggle="modal" data-target="#myModal">Learn More</a>
			</div>
								</div>	
							</div>
						</div>
					</li>
					<li>
						<div class="w3layouts-banner-top w3layouts-banner-top1">
							<div class="container">
								<div class="agileits-banner-info">
								<h4>IMPROVE </h4>
									<h3>the lives of others</h3>
										<p>Welcome to our website</p>
									<div class="agileits_w3layouts_more menu__item">
				<a href="#" class="menu__link" data-toggle="modal" data-target="#myModal">Learn More</a>
			</div>
								</div>	
							</div>
						</div>
					</li>
					<li>
						<div class="w3layouts-banner-top w3layouts-banner-top2">
							<div class="container">
								<div class="agileits-banner-info">
								<h4>Help</h4>
								<h3>the needy with your contributions </h3>
										<p>Welcome to our website</p>
									<div class="agileits_w3layouts_more menu__item">
											<a href="#" class="menu__link" data-toggle="modal" data-target="#myModal">Learn More</a>
										</div>
								</div>
							</div>
						</div>
					</li>
				</ul>
			</div>
			<div class="clearfix"> </div>
			<!--banner Slider starts Here-->
		</div>
	</div>	
	<!-- //banner --> 
<!--//Header-->
<!-- //Modal1 -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
		<!-- Modal1 -->
		<div class="modal-dialog">
			<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4>NIRVANA</h4>
							<img src="images/1.jpg" alt=" " class="img-responsive">
							<h5>A safe place where healing begins.</h5>
							<p>
Actions speak louder than words! So make an effort made for the happiness of others and be a part of the breakthrough and make someone’s dream come true.
Be part of a change in the World.Be wise through charity..</p>
					</div>
				</div>
		</div>
	</div>
<!-- //Modal1 -->
<!-- /about -->
 	<div class="about-wthree">
		<div class="container">
			<div class="ab-w3l-spa">
			<div class="w3layouts_head">
					<h3 class="tittle"> Welcome</h3>
						<div class="border"></div>
				</div>
               <p class="about-para-w3ls">A small charity has a big impact.<br>
                     This website helps you to donate your best to the people who are in need  and find the passion for your helping mind.<br> Not all of us can do great things but we can do small things with great love. Share your joy of charity. 
                   
                </p>
				<img src="../temp/images/about.jpg" class="img-responsive" alt="Hair Salon">
					<div class="w3l-slider-img">
						<img src="../temp/images/a1.jpg" class="img-responsive" alt="Hair Salon">
					</div>
                    <div class="w3ls-info-about">
						<h4>People live when people give</h4>
						<p> We can’t help everyone, but everyone can help someone.</p>
					</div>
		    </div>
		   	<div class="clearfix"> </div>
		</div>
	</div>
<!-- //about -->

<!--welcome-->
				<div class="service-w3l">
					<div class="container">
					<div class="w3layouts_head">
						<h3 class="tittle"> Our Services</h3>
						<div class="border"></div>
					</div>
						<div class="service-grids">
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-cog" aria-hidden="true"></i>
									</div>
									<h4>WEBSITE</h4>
									<p>This website is helpful for those who have a passion in helping others who are in need. They can also buy products made by the organisations.</p>
								</div>
							</div>
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-heart" aria-hidden="true"></i>
									</div>
									<h4>DONATIONS</h4>
									<p>Customers can donate their best to the organisations that has requested their needs.</p>
								</div>
							</div>
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-time" aria-hidden="true"></i>
									</div>
									<h4>PRODUCTS</h4>
									<p>We help the organisations in fund raising by selling their products to our worthy customers.</p>
								</div>
							</div>
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-pencil" aria-hidden="true"></i>
									</div>
									<h4>FEEDBACK</h4>
									<p>You can also provide your creative ideas to improve our functioning.</p>
								</div>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="service-grids">
							
				<!-- Counter -->
<div class="stats">
	<div class="container">	
		<div class="row">
			<div class="col-md-3 col-sm-3 stats-grid stats-grid-1 gridw3">
				<i class="fa fa-smile-o" aria-hidden="true"></i>
				<div class="numscroller" data-slno='1' data-min='0' data-max='158' data-delay='3' data-increment="1">85</div>
				<h4>Customers</h4>
			</div>
            <div class="col-md-3 col-sm-3 stats-grid stats-grid-1 gridw3">
				<i class="fa fa-smile-o" aria-hidden="true"></i>
				<div class="numscroller" data-slno='1' data-min='0' data-max='53' data-delay='3' data-increment="1">85</div>
				<h4>Organisations</h4>
			</div>
            <div class="col-md-3 col-sm-3 stats-grid stats-grid-1 gridw3">
				<i class="fa fa-smile-o" aria-hidden="true"></i>
				<div class="numscroller" data-slno='1' data-min='0' data-max='113' data-delay='3' data-increment="1">85</div>
				<h4>Products</h4>
			</div>
			
			<div class="col-md-3 col-sm-3 stats-grid stats-grid-4 gridw3">
				<i class="fa fa-users" aria-hidden="true"></i>
				<div class="numscroller" data-slno='1' data-min='0' data-max='245' data-delay='3' data-increment="1">90</div>
				<h4>Members</h4>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- //Counter -->

  
  	

   <!-- Footer -->
	<div class="w3l-footer">
		<div class="container">
         <div class="footer-info-agile">
				<div class="col-md-2 footer-info-grid links">
					<h4>Quick links</h4>
					<ul>
						        <li><a href="index.php">Home</a></li> 
								<li><a href="about.php">About</a></li> 
								
								<li><a href="gallery.php">Gallery</a></li> 
								<li><a href="contact.php">Contact</a></li> 
					</ul>
				</div>
				<div class="col-md-3 footer-info-grid address">
					<h4>Address</h4>
					<address>
						<ul>
							<li>Nirvana Charitable Trust</li>
							<li>Kakkanad,Ernakulam</li>
                            <li>682030</li>
							<li>Telephone : +91 94478 03022</li>
							<li>Email : <a class="mail" href="mailto:mail@example.com">nirvana@gmail.com</a></li>
						</ul>
					</address>
				</div>
				<div class="col-md-3 footer-grid">
				   <h4>Instagram</h4>
					<div class="footer-grid-instagram">
					<a href="#" data-toggle="modal" data-target="#myModal"><img src="../temp/images/g1.jpg" alt=" " class="img-responsive"></a>
					</div>
					<div class="footer-grid-instagram">
					<a href="#" data-toggle="modal" data-target="#myModal"><img src="../temp/images/g2.jpg" alt=" " class="img-responsive"></a>
					</div>
					<div class="footer-grid-instagram">
						<a href="#" data-toggle="modal" data-target="#myModal"><img src="../temp/images/g3.jpg" alt=" " class="img-responsive"></a>
					</div>
					<div class="footer-grid-instagram">
					<a href="#" data-toggle="modal" data-target="#myModal"><img src="../temp/images/g4.jpg" alt=" " class="img-responsive"></a>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-4 footer-info-grid">
				<div class="connect-social">
					<h4>Connect with us</h4>
					<section class="social">
                        <ul>
							<li><a class="icon fb" href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a class="icon tw" href="#"><i class="fa fa-twitter"></i></a></li>
							
							
							<li><a class="icon pin" href="#"><i class="fa fa-pinterest"></i></a></li>
							<li><a class="icon db" href="#"><i class="fa fa-dribbble"></i></a></li>
							<li><a class="icon gp" href="#"><i class="fa fa-google-plus"></i></a></li>
						</ul>
					</section>

				</div>
					

					
				</div>
				<div class="clearfix"></div>
			</div>

		<!--	<div class="connect-agileits newsletter">
				<h4>Newsletter</h4>
					<p>Subscribe to our newsletter and we will inform you about newest projects and promotions.
					</p>
					<form action="#" method="post" class="newsletter">
						<input class="email" type="email" placeholder="Your email address..." required="">
						<input type="submit" class="submit" value="Subscribe">
					</form>
			</div>  
	   </div>
     </div>         -->
	<div class="copy">
		<p>© 2019 NIRVANA . All Rights Reserved | Design by <a href="http://w3layouts.com/">W3layouts</a> </p>
	</div>
<!--/footer -->
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- flexSlider -->
				<script defer src="js/jquery.flexslider.js"></script>
				<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			  </script>
			<!-- //flexSlider -->
		<script src="js/responsiveslides.min.js"></script>
			<script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider4").responsiveSlides({
							auto: true,
							pager:true,
							nav:false,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
			</script>
		<!--search-bar-->
		<script src="js/main.js"></script>	
<!--//search-bar-->
	
	<!-- js for Counter -->
		<script type="text/javascript" src="js/numscroller-1.0.js"></script>
	<!-- /js for Counter -->

<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<div class="arr-w3ls">
		<a href="#home" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	</div>
<!-- //smooth scrolling -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
            
            
<!-- back button disable -->           
<script type="text/javascript">
       history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});
    </script>
 <!-- //back button disable --> 
</body>
</html>