<?php 
include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>
<HTML>
<HEAD>
<TITLE>DONATION UPDATE</TITLE>
<STYLE>
LABEL
{
	COLOR:black;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=EMAIL],[TYPE=PASSWORD],[TYPE=DATE],TEXTAREA,select
{
	BORDER-RADIUS:4PX;
	color:black;
	background-color:white;
	height:40px;
	width:290px;
	BORDER:1PX SOLID blue;
}
input[type=submit],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	width:70px;
	height:30px;
}
input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red
}

H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
}
TR
{
	HEIGHT:50PX;
}
.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
}
	</STYLE>
</HEAD>
<?php
$sql="select ifnull(max(d_id),0)+1 from donation_update";
$tbl=getDatas($sql);
    
?>
    <br><br><br><br><br>
<BODY>
<DIV CLASS="CONTAINER">
<H1>DONATION UPDATE</H1>
    <div id="err" style="color: red;height: 20px"></div>
<FORM action="" method="post">
<TABLE STYLE="POSITION:RELATIVE;LEFT:500PX;TOP:25PX">

<TR>
	<TD><LABEL><B>Title:</B></LABEL></TD>
	<TD><input type="TEXT" name="title"  onkeypress="return verifyText(event,'err')"REQUIRED=" "></TD>
</TR>

<TR>
	<TD><LABEL><B>Description:</B></LABEL></TD>
	<TD><textarea rows=""cols="" name="desc"  onkeypress="return verifyText(event,'err')"></textarea></TD>
</TR>
<TR>
	<TD><LABEL><B>Amount:</B></LABEL></TD>
	<TD><input type="text" NAME="amt" REQUIRED=" "></TD>
</TR>
 
 
     
<TR>
	<TD><LABEL><B>Time Limit:</B></LABEL></TD>
	<TD><input type="date" NAME="ndate" REQUIRED=" "></TD>
</TR>

<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><input type="SUBMIT" NAME="submit" VALUE="SUBMIT">
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="RESET"  value="CANCEL"></BR></BR>
        </TD>
</TR>

</TABLE>
</FORM>
</DIV>
</BODY>
</HTML>
     
<?php
if(isset($_POST['title']))
{
//$a=$tbl[0][0];
$b=$_POST['title'];
//echo $b;
$c=$_POST['desc'];
    //echo $c;
$d=$_POST['amt'];
$e=$_POST['ndate'];
    $sql="insert into donation_update values('$tbl[0][0]','$b','$c','$d','$e')";
setDatas($sql);
    msgbox('Successfully submitted');
    }
    ?>