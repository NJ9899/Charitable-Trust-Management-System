<?php include_once("../shares/db/mydatabase.inc");?>
 <?php include("top.php"); ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>
	<!--user--->
	<?php
	$sql="select * from tbl_order";
					$tbl=getDatas($sql);
		if($tbl==null)
		{
								echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>NO Orders...</font></div>";

		}	
else{		
?>
	<div class="checkout-right">
					<h1 style="position:relative;left:520px;top:100px;">Orders</h1>
				<table border="1" style="position:relative;width:900px;left:150px;top:150px">
					<thead>
						<tr>
						<th>Product</th>
							
							<th> Product Name</th>
							<th>Buyer</th>	
							<th>Price</th>
							<th>Order date</th>
							
							<th>Delivery Status</th>
							
							<th colspan=2>update</th>
							
						</tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr class="rem1">
						<td class="invert"><img src="<?php echo $tbl[$i][9];?>" style="position:relative;width:100px;height:100px;"></td>
						<td class="invert"><?php echo $tbl[$i][3];?></td>
						<td class="invert"><?php echo $tbl[$i][2];?>
							 
						</td>
						<td class="invert"><?php echo $tbl[$i][4];?></td>
						
						<td class="invert"><?php echo $tbl[$i][5];?></td>
						<td class="invert"><?php echo $tbl[$i][8];?>
							
						</td>
					
						<td class="invert"> <a href="delstatus.php?a=<?php echo $tbl[$i][0];?>"><font color="green"> STATUS</font></a></td>
					<?php 
					}
					}
					?>
					</tbody>
				
				</table>
			</div>
	<!--user-->
