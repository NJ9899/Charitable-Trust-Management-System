<?php
session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");
?>
<?php include("top.php");?>
<head>
<style>
 table{
     	 border: 2px solid #111;
                   border-radius:1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}
td{
	text-align:center;
}

    </style>
 </head>
<div style="position:relative;border:groove;width:200px;height:80px;border-radius:8px;background-color:bisque;top:100px;left:100px;">
<br>
	&emsp;&emsp;<a href="orph_info.php"><b>New Orphanages</b></a>
	
</div>
<?php

    $sql="select organisation.*,login.* from organisation join login on organisation.org_mail=login.username where login.status='1' and organisation.category='orphanage'";
		//$sql="select * from organisation where category='$m'";

	$tbl=getDatas($sql);
		
if($tbl==null)
{
		 					echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>No Approved Orphanges...</font></div>";

}
else{
?>
<div class="checkout-right">
					<h1 style="position:relative;left:320px;top:120px" > Orphanage Information </h1>

<table border="1" style="position:relative;width:900px;left:190px;top:150px">
<tr> 

<th>Organisation Name</th>
<th>City</th>
<th>District</th>
<th>Pincode</th>
<th>Email</th>
<th>Person Of Contact</th>
  
</tr>
<?php
		
		for($i=0;$i<count($tbl);$i++)
		{
			
			for($j=0;$j<count($tbl[$i]);$j++)
			{
			
			}
			?>
			<tr>
			<td class="invert"><?php echo $tbl[$i][1];?></td>
											 
						<td class="invert"><?php echo $tbl[$i][3];?></td>
						<td class="invert"><?php echo $tbl[$i][4];?></td>
						<td class="invert"><?php echo $tbl[$i][5];?></td>
                <td class="invert"><?php echo $tbl[$i][7];?></td>
                   <td class="invert"><?php echo $tbl[$i][10];?></td>             
	
	
	</tr>
	
 <?php
		}
 	}
		?>
		</table>
	</div>
		
		