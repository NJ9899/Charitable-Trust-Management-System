<!DOCTYPE html>
<html lang="en">
<head>
<title>Discipline an Educational Category Flat Bootstrap Responsive  Website Template | Home :: W3layouts</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Discipline Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/modernizr-2.6.2.min.js"></script>
<!--fonts-->
<link href="//fonts.googleapis.com/css?family=Oswald:300,400,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Federo" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
<!--//fonts-->
</head>
    
    <body>

<!-- //Modal1 -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
		<!-- Modal1 -->
		<div class="modal-dialog">
			<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4>DISCIPLINE</h4>
							<img src="images/1.jpg" alt=" " class="img-responsive">
							<h5>We know what you love</h5>
							<p>Providing guests unique and enchanting views from their rooms with its exceptional amenities, makes Star Hotel one of bests in its kind.Try our food menu, awesome services and friendly staff while you are here.</p>
					</div>
				</div>
		</div>
	</div>
<!-- //Modal1 -->
<!-- /about -->
 	<div class="about-wthree">
		<div class="container">
			<div class="ab-w3l-spa">
			<div class="w3layouts_head">
					<h3 class="tittle"> Welcome</h3>
						<div class="border"></div>
				</div>
               <p class="about-para-w3ls">Lorem Ipsum is simply dummy text of the printing and typesetting industry.Sed tempus vestibulum lacus blandit faucibus. Nunc imperdiet, diam nec rhoncus ullamcorper, nisl nulla suscipit ligula, at imperdiet urna</p>
				<img src="images/about.jpg" class="img-responsive" alt="Hair Salon">
					<div class="w3l-slider-img">
						<img src="images/a1.jpg" class="img-responsive" alt="Hair Salon">
					</div>
                    <div class="w3ls-info-about">
						<h4>You'll love all the amenities we offer!</h4>
						<p>Lorem ipsum dolor sit amet, ut magna aliqua. </p>
					</div>
		    </div>
		   	<div class="clearfix"> </div>
		</div>
	</div>
<!-- //about -->

<!--welcome-->
				<div class="service-w3l">
					<div class="container">
					<div class="w3layouts_head">
						<h3 class="tittle"> Our Services</h3>
						<div class="border"></div>
					</div>
						<div class="service-grids">
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-cog" aria-hidden="true"></i>
									</div>
									<h4>sit amet</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
								</div>
							</div>
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-heart" aria-hidden="true"></i>
									</div>
									<h4>dolor sit</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
								</div>
							</div>
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-time" aria-hidden="true"></i>
									</div>
									<h4>ipsum dolor</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
								</div>
							</div>
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-pencil" aria-hidden="true"></i>
									</div>
									<h4>Lorem ipsum</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
								</div>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="service-grids">
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-user" aria-hidden="true"></i>
									</div>
									<h4>sit amet</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
								</div>
							</div>
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-headphones" aria-hidden="true"></i>
									</div>
									<h4>Lorem ipsum</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
								</div>
							</div>
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-bell" aria-hidden="true"></i>
									</div>
									<h4>ipsum dolor</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
								</div>
							</div>
							<div class="col-md-3 ser-grid">
								<div class="ser-top">
									<div class="con hvr-shutter-in-horizontal">
										<i class="glyphicon glyphicon-picture" aria-hidden="true"></i>
									</div>
									<h4>dolor sit</h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do labore et dolore magna aliqua.</p>
								</div>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<!-- Counter -->
<div class="stats">
	<div class="container">	
		<div class="row">
			<div class="col-md-3 col-sm-3 stats-grid stats-grid-1 gridw3">
				<i class="fa fa-smile-o" aria-hidden="true"></i>
				<div class="numscroller" data-slno='1' data-min='0' data-max='158' data-delay='3' data-increment="1">85</div>
				<h4>Happy Customers</h4>
			</div>
			<div class="col-md-3 col-sm-3 stats-grid stats-grid-2 gridw3">
				<i class="fa fa-trophy" aria-hidden="true"></i>
				<div class="numscroller" data-slno='1' data-min='0' data-max='63' data-delay='3' data-increment="1">95</div>
				<h4>Awards </h4>
			</div>
			<div class="col-md-3 col-sm-3 stats-grid stats-grid-3 gridw3">
				<i class="fa fa-laptop" aria-hidden="true"></i>
				<div class="numscroller" data-slno='1' data-min='0' data-max='421' data-delay='3' data-increment="1">80</div>
				<h4>Courses</h4>
			</div>
			<div class="col-md-3 col-sm-3 stats-grid stats-grid-4 gridw3">
				<i class="fa fa-users" aria-hidden="true"></i>
				<div class="numscroller" data-slno='1' data-min='0' data-max='562' data-delay='3' data-increment="1">90</div>
				<h4>Members</h4>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- //Counter -->
<!-- news -->
	<div class="w3-news"> 
		<div class="container"> 
			<div class="w3layouts_head">
				<h3 class="tittle">Latest News</h3>
					<div class="border"></div>
				</div>
			<div class="news-info">
				<div class="col-md-6 event-grids">
					<div class="w3layouts-text">
						<h4>10<span>May</span></h4>
						<h6><a href="#" data-toggle="modal" data-target="#myModal">Nulla tellus exquis</a></h6>
						<div class="clearfix"> </div>
					</div>
					<p>Kasertas lertyasea deeraeser miasera lertasa ritise doloert ferdas caplicabo nerafaes asety u lasec vaserat. nikertyade asetkertyptaiades goertayse.nikertyade asetkertyptaiades goertayse</p>
				</div>
				<div class="col-md-6 event-grids">
					<div class="w3layouts-text">
						<h4>20<span>Jun</span></h4>
						<h6><a href="#" data-toggle="modal" data-target="#myModal">Mauris vehicula vel</a></h6>
						<div class="clearfix"> </div>
					</div>
					<p>Kasertas lertyasea deeraeser miasera lertasa ritise doloert ferdas caplicabo nerafaes asety u lasec vaserat. nikertyade asetkertyptaiades goertayse.nikertyade asetkertyptaiades goertayse</p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="news-info news-agileinfo2">
				<div class="col-md-6 event-grids">
					<div class="w3layouts-text">
						<h4>05<span>Jul</span></h4>
						<h6><a href="#" data-toggle="modal" data-target="#myModal">Nulla tellus exquis</a></h6>
						<div class="clearfix"> </div>
					</div>
					<p>Kasertas lertyasea deeraeser miasera lertasa ritise doloert ferdas caplicabo nerafaes asety u lasec vaserat. nikertyade asetkertyptaiades goertayse.nikertyade asetkertyptaiades goertayse</p>
				</div>
				<div class="col-md-6 event-grids">
					<div class="w3layouts-text">
						<h4>18<span>Aug</span></h4>
						<h6><a href="#" data-toggle="modal" data-target="#myModal">Mauris vehicula vel</a></h6>
						<div class="clearfix"> </div>
					</div>
					<p>Kasertas lertyasea deeraeser miasera lertasa ritise doloert ferdas caplicabo nerafaes asety u lasec vaserat. nikertyade asetkertyptaiades goertayse.nikertyade asetkertyptaiades goertayse</p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div> 
	</div> 
	<!-- //news -->
  <!-- visitors -->
	<div class="w3l-visitors-agile" >
		<div class="container">
			<div class="w3layouts_head">
				<h3 class="tittle">Testimonials</h3>
					<div class="border"></div>
				</div>
			</div>
		<div class="w3layouts_work_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="w3layouts_work_grid_left">
								<img src="images/3.jpg" alt=" " class="img-responsive" />
								<div class="w3layouts_work_grid_left_pos">
									<img src="images/teamb1.jpg" alt=" " class="img-responsive" />
								</div>
							</div>
							<div class="w3layouts_work_grid_right">
								<h4>
								Vestibulum lacus blandit
								</h4>
								<p>Sed tempus vestibulum lacus blandit faucibus. 
									Nunc imperdiet, diam nec rhoncus ullamcorper, nisl nulla suscipit ligula, 
									at imperdiet urna. </p>
								<h5>Julia Rose</h5>
								<p>Tempus</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="w3layouts_work_grid_left">
								<img src="images/2.jpg" alt=" " class="img-responsive" />
								<div class="w3layouts_work_grid_left_pos">
									<img src="images/teamb2.jpg" alt=" " class="img-responsive" />
								</div>
							</div>
							<div class="w3layouts_work_grid_right">
								<h4>
								Worth to come again
								</h4>
								<p>Sed tempus vestibulum lacus blandit faucibus. 
									Nunc imperdiet, diam nec rhoncus ullamcorper, nisl nulla suscipit ligula, 
									at imperdiet urna. </p>
								<h5>Jahnatan Smith</h5>
								<p>Tempus</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="w3layouts_work_grid_left">
								<img src="images/1.jpg" alt=" " class="img-responsive" />
								<div class="w3layouts_work_grid_left_pos">
									<img src="images/teamb3.jpg" alt=" " class="img-responsive" />
								</div>
							</div>
							<div class="w3layouts_work_grid_right">
								<h4>
								Worth to come again
								</h4>
								<p>Sed tempus vestibulum lacus blandit faucibus. 
									Nunc imperdiet, diam nec rhoncus ullamcorper, nisl nulla suscipit ligula, 
									at imperdiet urna. </p>
								<h5>Rosalind Cloer</h5>
								<p>Tempus</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="w3layouts_work_grid_left">
								<img src="images/2.jpg" alt=" " class="img-responsive" />
								<div class="w3layouts_work_grid_left_pos">
									<img src="images/teamb4.jpg" alt=" " class="img-responsive" />
								</div>
							</div>
							<div class="w3layouts_work_grid_right">
								<h4>
								Worth to come again
								</h4>
								<p>Sed tempus vestibulum lacus blandit faucibus. 
									Nunc imperdiet, diam nec rhoncus ullamcorper, nisl nulla suscipit ligula, 
									at imperdiet urna. </p>
								<h5>Amie Bublitz</h5>
								<p>Tempus</p>
							</div>
							<div class="clearfix"> </div>
						</li>
					</ul>
				</div>
			</section>
		</div>	
	</div>
  <!-- visitors -->
    
    
    <!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- flexSlider -->
				<script defer src="js/jquery.flexslider.js"></script>
				<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			  </script>
			<!-- //flexSlider -->
		<script src="js/responsiveslides.min.js"></script>
			<script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider4").responsiveSlides({
							auto: true,
							pager:true,
							nav:false,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
			</script>
		<!--search-bar-->
		<script src="js/main.js"></script>	
<!--//search-bar-->
	
	<!-- js for Counter -->
		<script type="text/javascript" src="js/numscroller-1.0.js"></script>
	<!-- /js for Counter -->

<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<div class="arr-w3ls">
		<a href="#home" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	</div>
<!-- //smooth scrolling -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
</body>
</html>