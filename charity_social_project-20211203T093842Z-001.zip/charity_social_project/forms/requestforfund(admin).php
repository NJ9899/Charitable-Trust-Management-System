<HTML>
<HEAD>
<TITLE>FUND REQUEST</TITLE></HEAD>
<STYLE>
LABEL
{
	COLOR:black;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=EMAIL],[TYPE=PASSWORD],TEXTAREA
{
	BORDER-RADIUS:4PX;
	color:black;
	background-color:white;
	height:40px;
	width:290px;
	BORDER:1PX SOLID blue;
}
input[type=submit],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	width:70px;
	height:30px;
}
input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red
}
H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
}
TR
{
	HEIGHT:50PX;
}
.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
}
	</STYLE>
</HEAD>
<BODY>
<DIV CLASS="CONTAINER">
<H1>REQUEST FOR FUND</H1>
<FORM>
<TABLE STYLE="POSITION:RELATIVE;LEFT:500PX;TOP:25PX">

<TR>
	<TD><LABEL><B>ORGANIZATION NAME:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="dname" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>ADDRESS:</B></LABEL></TD>
	<TD><TEXTAREA rows=""cols="" NAME="address" REQUIRED=" "></textarea></TD>
</TR>
<TR>
	<TD><LABEL><B>PHONE NO:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="dphno" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>EMAIL:</B></LABEL></TD>
	<TD><INPUT TYPE="EMAIL" NAME="demail" REQUIRED=" "></TD>
</TR>
<TR>
     <TD><LABEL><B>NEEDED AMOUNT:</B></LABEL></TD>
	 <TD><INPUT TYPE="TEXT" NAME="amt" REQUIRED=" "></TD>
</TR>
<TR>
     <TD><LABEL><B>PURPOSE:</B></LABEL></TD>
	 <TD><INPUT TYPE="TEXT" NAME="pur" REQUIRED=" "></TD>
</TR>
<TR>
     <TD><LABEL><B>TARGET DATE:</B></LABEL></TD>
	 <TD><INPUT TYPE="TEXT" NAME="tard" REQUIRED=" "></TD>
</TR>
<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><INPUT TYPE="SUBMIT" NAME="submit" VALUE="SUBMIT">
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"></TD>
</TR>

</TABLE>
</FORM>
</DIV>
</BODY>
</HTML>