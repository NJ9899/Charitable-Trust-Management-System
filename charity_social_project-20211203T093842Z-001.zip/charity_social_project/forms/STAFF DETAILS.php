<HTML>
<HEAD><TITLE>STAFF DETAILS</TITLE>
<style>
LABEL
{
	COLOR:#008080;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=DATE],[TYPE=EMAIL],TEXTAREA
{
	BORDER-RADIUS:4PX;
	background-color:#ccc;
	height:25px;
	width:290px;
	BORDER:1PX SOLID #008080;
}
INPUT[TYPE=SUBMIT],INPUT[TYPE=RESET]
{
	BACKGROUND-COLOR:light cyan;
	COLOR:BLACK;
	HEIGHT:2X;
	WIDTH:75PX;
}
INPUT[TYPE=SUBMIT]:HOVER,INPUT[TYPE=RESET]:HOVER
{
	background-color:#CCFF66;
}
H1
{
	color:blue;
	text-align:center;
	FONT-SIZE:200%;
}
TR
{
	HEIGHT:50PX;
}
.CONTAINER
{

	BACKGROUND-COLOR:#CCFFFF;
	HEIGHT:590;
}
	</STYLE>
</HEAD>
<BODY BACKGROUND-COLOR="ORANGE">
<DIV CLASS="CONTAINER">
<H1>STAFF DETAILS</H1>
<FORM>
<TABLE STYLE="POSITION:RELATIVE;LEFT:250PX;TOP:25PX">
<TR>
	<TD><LABEL><B>STAFF ID:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="sid"></TD>
</TR>
<TR>
	<TD><LABEL><B>STAFF NAME:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="sname"></TD>
</TR>
<TR>
	<TD><LABEL><B>ADDRESS:</B></LABEL></TD>
	<TD><TEXTAREA rows="3"cols="" NAME="address"></textarea></TD>
</TR>
<TR>	
	<TD><LABEL><B>GENDER</B></LABEL></TD>
	<TD><INPUT TYPE="RADIO" NAME="gender" VALUE="male">MALE
	<INPUT TYPE="RADIO" NAME="gender" VALUE="female">FEMALE</TD>
<TR>
	<TD><LABEL><B>PHONE NO:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="sphno"></TD>
</TR>
<TR>
	<TD><LABEL><B>STAFF EMAIL:</B></LABEL></TD>
	<TD><INPUT TYPE="EMAIL" NAME="semail"></TD>
</TR>
<TR>
	<TD><LABEL><B>JOIN DATE</B></LABEL></TD>
	<TD><INPUT TYPE="DATE" NAME="sjd"></TD>
</TR>
<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><INPUT TYPE="SUBMIT" NAME="submit" VALUE="SUBMIT">
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"></TD>
</TR>

</TABLE>
</FORM>
</DIV>
</BODY>
<HTML>


	