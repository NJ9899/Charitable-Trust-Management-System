<html>
<head>
<title>login</title>
<style>

input[type=text],input[type=password]
{
	border-radius:3px;
	height:50px;
	width:300px;
}

input[type=submit],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	width:70px;
	height:30px;
}
input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red
}
table
{
	border-radius:3px;
	height:100px;
	
}



</style>
</head>
<body>
<center>

<form>
<table>
<h1>LOGIN FORM</h1><br><br>
<tr>
<td>
<label>LOGIN ID :</label>
</td><td>
<input type="text" name="id"></td>
</tr>
<tr>
<td>
<label>PASSWORD:</label></td>
<td><input type="password" name="password"></td>
</tr>

</table><br><br>
<input type="submit" name="submit1" value="Login">&nbsp;&nbsp;&nbsp;&nbsp;
<input type="reset" name="reset" value="Reset">
</table></form></center>
</body></html>