<HTML>
<HEAD><TITLE>DONOR DETAILS</TITLE>
<style>
LABEL
{
	COLOR:black;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=DATE],[TYPE=EMAIL],[TYPE=PASSWORD],TEXTAREA
{
	BORDER-RADIUS:4PX;
	color:black;
	background-color:white;
	height:40px;
	width:290px;
	BORDER:1PX SOLID blue;
}
INPUT[TYPE=SUBMIT],INPUT[TYPE=RESET]
{
	background-color:tomato;
	color:white;
	border:none;
	border-radius:30px;
	height:30px;
	width:80px;
	font-weight:bold;
	margin-right:20px;
	margin-top:20px;
	position:relative;
	left:100px;
}
INPUT[TYPE=SUBMIT]:HOVER,INPUT[TYPE=RESET]:HOVER
{
	background-color:#CCFF66;
}
H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
}
TR
{
	HEIGHT:50PX;
}
.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
}
	</STYLE>
</HEAD>
<BODY>
<DIV CLASS="CONTAINER">
<H1>DONOR DETAILS</H1>
<FORM>
<TABLE STYLE="POSITION:RELATIVE;LEFT:500PX;TOP:25PX">

<TR>
	<TD><LABEL><B>CUSTOMER NAME:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="dname" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>ADDRESS:</B></LABEL></TD>
	<TD><TEXTAREA rows=""cols="" NAME="address" REQUIRED=" "></textarea></TD>
</TR>
<TR>	
	<TD><LABEL><B>GENDER</B></LABEL></TD>
	<TD><INPUT TYPE="RADIO" NAME="gender" VALUE="male">MALE
	<INPUT TYPE="RADIO" NAME="gender" VALUE="female">FEMALE</TD>
<TR>
	<TD><LABEL><B>PHONE NO:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="dphno" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>CUSTOMER EMAIL:</B></LABEL></TD>
	<TD><INPUT TYPE="EMAIL" NAME="demail" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>JOIN DATE</B></LABEL></TD>
	<TD><INPUT TYPE="DATE" NAME="djd"></TD>
</TR>
<TR>
	<TD><LABEL><B>PASSWORD:</B></LABEL></TD>
	<TD><INPUT TYPE="PASSWORD" NAME="dpass" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>RE-ENTER PASSWORD:</B></LABEL></TD>
	<TD><INPUT TYPE="PASSWORD" NAME="dpass" REQUIRED=" "></TD>
</TR>

<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><INPUT TYPE="SUBMIT" NAME="submit" VALUE="SUBMIT">
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"></TD>
</TR>

</TABLE>
</FORM>
</DIV>
</BODY>
</HTML>


	