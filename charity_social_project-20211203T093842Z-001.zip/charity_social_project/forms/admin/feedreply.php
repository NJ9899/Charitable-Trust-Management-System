<?php include_once("../shares/db/mydatabase.inc");?>
 <?php include("admin_top.php"); ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>
	<!--user--->
	<?php
	$sql="select * from feedback";
					$tbl=getDatas($sql);
					if($tbl==null){
						echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>Sorry No Feedbacks...</font></div>";

					}
					else
					{
?>
	<div class="checkout-right">
					<h1 style="position:relative;left:520px;top:100px;">FEEDBACK</h1>
				<table border="1" style="position:relative;width:900px;left:150px;top:150px">
					<thead>
						<tr>
							
							<th> Name</th>
							<th>Feddback</th>
							
							
							<th colspan=2>Reply</th>
							
						</tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr class="rem1">
						
						<td class="invert"><?php echo $tbl[$i][1];?></td>
						<td class="invert"><?php echo $tbl[$i][2];?>
							 
						</td>
						
							
						</td>
					
						<td class="invert"> <a href="feedreply.php?a=<?php echo $tbl[$i][0];?>"><font color="green">comment</font></a></td>
					<?php 
					}
					}
					?>
					</tbody>
				
				</table>
			</div>
	<!--user-->
