<HTML>
<HEAD><TITLE>ADD ORGANISATION</TITLE>
<style>
LABEL
{
	COLOR:darkmagenta;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=DATE],[TYPE=EMAIL],[TYPE=PASSWORD],SELECT,TEXTAREA
{
	BORDER-RADIUS:4PX;
	color:black;
	BACKGROUND-COLOR:#CCC;
	height:25px;
	width:290px;
	BORDER:1px solid red;
}

INPUT[TYPE=SUBMIT]
{
	background-color:tomato;
	color:white;
	border:none;
	border-radius:30px;
	height:30px;
	width:80px;
	font-weight:bold;
	margin-right:20px;
	margin-top:20px;
	position:relative;
	left:200px;
}
H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
	position:relative;
	left:100px;
}
TR
{
	HEIGHT:50PX;
}
.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
}
	</STYLE>
</HEAD>
<BODY>
<DIV CLASS="CONTAINER">
<H1>ADD ORGANISATION</H1>
<FORM>
<TABLE STYLE="POSITION:RELATIVE;LEFT:500PX;TOP:25PX">
<TR>
	<TD><LABEL><B>ORGANISATION ID:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="oid" ></TD>
</TR>
<TR>
	<TD><LABEL><B>ORGANISATION NAME:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="oname" REQUIRED=" "></TD>
</TR>
<tr>
<TD><LABEL><B>CATEGORY:</B></LABEL></TD>
<td><select name="category">
<option>--Select category--</option>
<option value="orphanage">ORPHANAGE</option>
<option value="women's welfare">WOMEN'S WELFARE</option>
<option value="old age home">OLD AGE HOME</option>
</tr>
<TR>
	<TD><LABEL><B>ADDRESS:</B></LABEL></TD>
	<TD><TEXTAREA rows="3"cols="" NAME="address" REQUIRED=" "></textarea></TD>
</TR>
<TR>	
	<TD><LABEL><B>LICENSE PROOF:</B></LABEL></TD>
	<TD><INPUT TYPE="FILE" NAME="license" REQUIRED=" "></TD>
<TR>
	<TD><LABEL><B>PHONE NO:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="ophno" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>EMAIL:</B></LABEL></TD>
	<TD><INPUT TYPE="EMAIL" NAME="oemail" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>PASSWORD:</B></LABEL></TD>
	<TD><INPUT TYPE="PASSWORD" NAME="opass" REQUIRED=" "></TD>
</TR>

<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><INPUT TYPE="SUBMIT" NAME="submit2" VALUE="ADD">
	</TD>
</TR>

</TABLE>
</FORM>
</DIV>
</BODY>
<HTML>


	