<html>
<head>
<title>feedback</title>
<style>
h1
{
	color:blue;
}
label
{
	COLOR:black;
	FONT-SIZE:100%;
}
TEXTAREA
{
 height:200px;
 width:290px;
 BORDER-RADIUS:4PX;
 color:black;
 background-color:#ccc;
 BORDER:1PX SOLID blue;
}
INPUT[TYPE=TEXT]
{
	BORDER-RADIUS:4PX;
	color:black;
	background-color:#ccc;
	height:25px;
	width:290px;
	BORDER:1PX SOLID blue;
}
INPUT[TYPE=SUBMIT],INPUT[TYPE=RESET]
{
	BACKGROUND-COLOR:powderblue;
	COLOR:BLACK;
	HEIGHT:2X;
	WIDTH:75PX;
}
INPUT[TYPE=SUBMIT]:HOVER,INPUT[TYPE=RESET]:HOVER
{
	background-color:#CCFF66;
}
</style>
</head>
<body>
<CENTER><h2>FEEDBACK</h2></CENTER>
<form style="position:relative top:50px left:100px">
<table>
<tr>
<td><label>DONOR:</label></td>
<TD><INPUT TYPE="TEXT" NAME="dname"></TD>
</tr>
&nbsp &nbsp &nbsp
<tr>
<td><label>Enter your feedback:</label></td>
<td><textarea rows=""cols="" name="feedback"></textarea></td>
</tr>
</table></form>
</body></html>