<?php include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>

<html>
<head>
<title>add_customer</title>
<style>
input[type=date],input[type=text],input[type=email],input[type=password],textarea,select
{
	
	border-radius:4px;
	width:300px;
	height:40px;
}
input[type=radio]
    {
       width:30px;
	   height:10px; 
    }
label
{
	color:red;
}
input[type=submit],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	border-radius:30px;
	height:30px;
	width:80px;
	font-weight:bold;
	margin-right:20px;
	margin-top:20px;
	position:relative;
	left:200px;
}
input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red;
}
table
{
	height:700px;
}
</style>
    <script src="maha.js"></script>

</head>
    <?php
$sql="select ifnull(max(cust_id),0)+1 from customer";
$tbl=getDatas($sql);

?>

<body>
     <div style="position:relative;border:groove;width:700px;left:350px;top:50px;height:790px">

<center>
<h1>CUSTOMER REGISTRATION</h1>
    <div id="err" style="color: red;height: 20px"></div>
    <br>
    <br>
<form action="" method="post">

<table>
    <tr>
<td>
<label>CUSTOMER ID:</label></td> 
<td><input type="text" name="id" value="<?php echo $tbl[0][0];?>" readonly></td></tr>

<tr>
<td>
<label>NAME:</label></td> 
<td><input type="text" name="cname1" onkeypress="return verifyText(event,'err')" required></td></tr>
<tr>
<tr>
<td>
<label>GENDER:</label></td> 
<td><input type="radio" name="gender" value="male" checked>Male
    <input type="radio" name="gender" value="female" >Female</td></tr>
<tr>
<td>
<label>HOUSENO:</label></td>
<td><input type="text" name="hno"> 
</td></tr>
<tr>
<td>
<label>CITY:</label></td>
<td><input type="text" name="city" onkeypress="return verifyText(event,'err')" required></td></tr>
<tr>
<td>
<label>DISTRICT:</label></td>
<td><input type="text" name="dis" onkeypress="return verifyText(event,'err')" required></td></tr>
<tr>
<td>
<label>PINCODE:</label></td>
<td><input type="text" name="pin"></td></tr>
<tr>
<td>
<label>EMAIL:</label></td>
<td><input type="email" name="email1"></td>
</tr>    
<tr>
<td>
<label>PHONE NUMBER:</label></td> 
<td><input type="text" name="num1"  onkeypress="return verifyPhone(this,event,'err')" onblur="return varifyLength(this,'err',10,10);" required ></td></tr>

<tr>
<td>
<label>PASSWORD:</label></td> 
<td><input type="password" name="password" required="" onkeypress="return verifyText(event,'err')"></td></tr>
    
<tr>
<td>
<label>CONFIRM PASSWORD:</label></td> 
<td><input type="password" name="cpwd" required="" onkeypress="return verifyText(event,'err')"></td></tr>
    

<center><tr>
<td>
<input type="submit" name="submit1" value="ADD">
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"></td></tr></center>
</table>
</form>
</center>
    </div>
</body></html>
<?php
if(isset($_POST['id']))
{
$a=$_POST['id'];
echo $a;
$b=$_POST['cname1'];
echo $b;
$i=$_POST['gender'];
$c=$_POST['hno'];
$d=$_POST['city'];
$e=$_POST['dis'];
$f=$_POST['password'];
$g=$_POST['cpwd'];
$h=$_POST['email1'];
$k=$_POST['num1'];
    $r=$_POST['pin'];
if($f==$g)
{
$sql="insert into customer values('$a','$b','$i','$c','$d','$e','$r','$h','$k')";
setDatas($sql);
$sql="insert into login values('$h','$f','customer','1')";
		setDatas($sql);
		msgbox('Successfully registerd');
}
else
{
  echo "password missmatch";
}
}

?>
