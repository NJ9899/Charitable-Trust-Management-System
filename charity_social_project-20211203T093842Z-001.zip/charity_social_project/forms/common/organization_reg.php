<?php include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>

<HTML>
<HEAD><TITLE>ADD ORGANISATION</TITLE>
<style>
LABEL
{
	COLOR:darkmagenta;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=DATE],[TYPE=EMAIL],[TYPE=PASSWORD],SELECT,TEXTAREA
{
	BORDER-RADIUS:4PX;
	color:black;
	BACKGROUND-COLOR:#CCC;
	height:25px;
	width:290px;
	BORDER:1px solid red;
}

INPUT[TYPE=SUBMIT]
{
	background-color:tomato;
	color:white;
	border:none;
	border-radius:30px;
	height:30px;
	width:80px;
	font-weight:bold;
	margin-right:20px;
	margin-top:0px;
	position:relative;
	left:200px;
}
H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
	position:relative;
	left:100px;
}
tr
{
	HEIGHT:50PX;
}
.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
}
	</STYLE>
</HEAD>
    <?php
$sql="select ifnull(max(org_id),0)+1 from organisation";
    $tbl=getDatas($sql);

?>
<BODY>
    <div style="position:relative;border:groove;width:700px;left:350px;top:50px;height:800px">
<DIV CLASS="CONTAINER">
<H1>ADD ORGANISATION</H1>
<FORM action="" method="post">
<TABLE STYLE="POSITION:RELATIVE;LEFT:50PX;TOP:25PX">
<tr>
	<td><LABEL><B>ORGANISATION ID:</B></LABEL></td>
	<td><INPUT TYPE="TEXT" NAME="oid" value="<?php echo $tbl[0][0];?>" readonly></td>
</tr>
<tr>
	<td><LABEL><B>ORGANISATION NAME:</B></LABEL></td>
	<td><INPUT TYPE="TEXT" NAME="oname" REQUIRED=" "></td>
</tr>
<tr>
<td><LABEL><B>CATEGORY:</B></LABEL></td>
<td><select name="category">
<option>--Select category--</option>
<option value="orphanage">ORPHANAGE</option>
<option value="womenwelfare">WOMEN'S WELFARE</option>
<option value="oldagehome">OLD AGE HOME</option></td>
</tr>
<tr>
	<td><LABEL><B>CITY:</B></LABEL></td>
	<td><input type="text" NAME="city" REQUIRED=" "></td>
</tr>
<tr>
	<td><LABEL><B>DIStrICT:</B></LABEL></td>
	<td><input type="text" NAME="district" REQUIRED=" "></td>
</tr>
<tr>
	<td><LABEL><B>PINCODE:</B></LABEL></td>
	<td><input type="text" NAME="pin" REQUIRED=" "></td>
</tr>

<tr>	
	<td><LABEL><B>LICENSE PROOF:</B></LABEL></td>
	<td><INPUT TYPE="FILE" NAME="reg" REQUIRED=" "></td>
    </tr>
<tr>
	<td><LABEL><B>ORGANIZATION EMAIL:</B></LABEL></td>
	<td><input type="text" NAME="email" REQUIRED=" "></td>
</tr>
<tr>
	<td><LABEL><B>PHONE NO:</B></LABEL></td>
	<td><INPUT TYPE="TEXT" NAME="ophno" REQUIRED=" "></td>
</tr>
<tr>
	<td><LABEL><B>PERSON OF CONTACT</B></LABEL></td>
	<td><input type="text" NAME="poc" REQUIRED=" "></td>
</tr>
<tr>
	<td><LABEL><B>PERSON OF CONTACT PHONE NO:</B></LABEL></td>
	<td><input type="text" NAME="pocno" REQUIRED=" "></td>
</tr>

<tr>
	<td><LABEL><B>PASSWORD:</B></LABEL></td>
	<td><INPUT TYPE="PASSWORD" NAME="opass" REQUIRED=" "onkeypress="return verifyText(event,'err')"></td>
</tr>
<tr>
<td>
<label>CONFIRM PASSWORD:</label></td> 
<td><input type="password" name="cpwd" required="" onkeypress="return verifyText(event,'err')"></td></tr>
    

<tr>
	<td>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><INPUT TYPE="SUBMIT" NAME="submit2" VALUE="ADD">
	</td>
</tr>

</TABLE>
</FORM>
</DIV>
    </div>
</BODY>
<HTML>
<?php
if(isset($_POST['oid']))
{
$a=$_POST['oid'];
echo $a;
$b=$_POST['oname'];
echo $b;
$c=$_POST['category'];
$d=$_POST['city'];
$e=$_POST['district'];
$f=$_POST['pin'];
$g=$_POST['reg'];
$h=$_POST['email'];
$i=$_POST['ophno'];
$j=$_POST['poc'];
$k=$_POST['pocno'];
$l=$_POST['opass'];
$m=$_POST['cpwd'];
if($l==$m)
{
$sql="insert into organisation values('$a','$b','$c','$d','$e','$f','$g','$h','$i','$j','$k')";
setDatas($sql);
$sql="insert into login values('$h','$l','$c','1')";
		setDatas($sql);
		msgbox('Successfully registerd');
}
else
{
  echo "password missmatch";
}
}

?>



	