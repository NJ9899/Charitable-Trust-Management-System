<?php include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>
<html>
<head>
<title>feedback</title>
<style>
h1
{
	color:blue;
}
label
{
	COLOR:BLACK;
}
TEXTAREA
{
 height:100px;
 width:290px;
 BORDER-RADIUS:4PX;
 color:black;
 background-color:white;
 BORDER:1PX SOLID red;
}
INPUT[TYPE=TEXT],INPUT[TYPE=SUBMIT],INPUT[TYPE=RESET],INPUT[TYPE=DATE]
{
	BORDER-RADIUS:4PX;
	color:black;
	background-color:white;
	height:25px;
	width:290px;
	BORDER:1PX SOLID red;
}
INPUT[TYPE=SUBMIT],INPUT[TYPE=RESET]
{
	BACKGROUND-COLOR:powderblue;
	COLOR:BLACK;
	HEIGHT:2X;
	WIDTH:75PX;
}
INPUT[TYPE=SUBMIT]:HOVER,INPUT[TYPE=RESET]:HOVER
{
	background-color:RED;
}
</style>
</head>
<?php
$sql="select ifnull(max(feed_id),0)+1 from feedback";
$tbl=getDatas($sql);

?>
<body>
<br><br>
<CENTER><h2>FEEDBACK</h2>
    <br><br>
<form action="" method="post">
<table style="position:relative top:500px left:100px">

<tr>
<td><label><B>CUSTOMER EMAIL:</B></label></td>
<TD><INPUT TYPE="TEXT" NAME="email1"></TD>
   

</tr>

<td><label><B>ENTER THE FEEDBACK:</B></label></td>
<td><textarea rows=""cols="" name="feedback"></textarea></td>
</tr>
<TR>
	<TD><LABEL><B>DATE:</B></LABEL></TD>
	<TD><INPUT TYPE="DATE" NAME="date"></TD>
</TR>
<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><INPUT TYPE="SUBMIT" NAME="submit" VALUE="SUBMIT">
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"></TD>
</TR>
</table></form>
        </CENTER>
</body></html>
    <?php
if(isset($_POST['email1']))
{
$a=$tbl[0][0];
$b=$_POST['email1'];

$c=$_POST['feedback'];
$d=$_POST['date'];
    $sql="insert into feedback values('$a','$b','$c','$d')";
setDatas($sql);
    msgbox('Successfully send');
}
    ?>
    