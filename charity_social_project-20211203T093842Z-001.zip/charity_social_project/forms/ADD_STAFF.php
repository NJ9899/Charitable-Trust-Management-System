<html>
<head>
<title>add_staff</title>
<style>
input[type=date],input[type=text],input[type=email],input[type=password],textarea,select
{
	
	border-radius:4px;
	width:300px;
	height:40px;
}
label
{
	color:red;
}
input[type=submit],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	border-radius:30px;
	height:30px;
	width:80px;
	font-weight:bold;
	margin-right:20px;
	margin-top:20px;
	position:relative;
	left:200px;
}
input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red;
}
table
{
	height:500px;
}
</style>
</head>

<body>
<center>
<h1>ADD STAFF</h1>
<form>

<table>
<tr>
<td>
<label>STAFF NAME:</label></td> 
<td><input type="text" name="dname1"></td></tr>
<tr>
<td>
<label>GENDER:</label></td>
<td><input type="radio" name="gender" value="female">Female
<input type="radio" name="gender" value="male">Male
</td></tr>
<tr>
<td>
<label>JOIN DATE:</label></td> 
<td><input type="date" name="ddate1"></td></tr>
<tr>
<td>
<label>ADDRESS:</label></td>
<td><textarea rows="4" cols="50"> </textarea></td></tr>
<tr>
<td>
<label>PHONE NUMBER:</label></td> 
<td><input type="text" name="name1"></td></tr>
<tr>
<td>
<label>EMAIL:</label></td>
<td><input type="email" name="email1"></td>
</tr>
<tr>
<td>
<input type="submit" name="submit1" value="ADD"></td></tr></center>
</table>
</form>
</center>
</body></html>