<?php session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");?>
 <?php include("top.php"); ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
    text-align: center;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
    text-align: center;
}
.card{
  background: rgba(0,0,0,0.8);
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.9);
  width:700px;
    height:800px;
  margin: auto;
    
  text-align: center;
  font-family: arial;
    
}



body{
        background-image: url("images/5.jpg") ;
        background-size: cover;
        background-repeat: no-repeat;
        height: 1000px;    
    }
    </style>
 </head>
	<!--user--->
	<?php
    $sql="select org_id from organisation where org_mail='$user'";
    $tbl=getDatas($sql);
    $p=$tbl[0][0];
	if(isset($_GET['mode']))
{

 $m=$_GET['mode'];
 //echo $m;
 if($m=="clayproducts")
{
				$sql="select * from add_product where prdt_type='$m' and org_id='$p'";


}
   else if($m=="handicrafts")
{
				$sql="select * from add_product where prdt_type='$m' and org_id='$p'";


}

else{
				$sql="select * from add_product where prdt_type='$m' and org_id='$p'";


}
	$tbl=getDatas($sql);
			$msg = mysql_error();
			if(!isset($msg) || $msg==''){
			$msg = "Success !!!";
		}
}
					if($tbl==null){
						echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>No Products...</font></div>";

					}
					else
					{
?>
	<div class="checkout-right">
					<h1 style="position:relative;left:520px;top:100px;"><b>PRODUCT VIEW</b></h1>
				<table border="1" style="position:relative;width:900px;left:200px;top:150px;">
					<thead>
						<tr>
							
                            <th>PRODUCT NAME</th>
                            <th>PRODUCT TYPE</th>
                            <th>PRICE</th>
                             <th>QUANTITY</th>
                            <th>DATE</th>
                            <th>PRODUCT IMAGE</th>
                           
				       </tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr >
						
						<td style="background-color:white;"><?php echo $tbl[$i][1];?></td>
                        <td style="background-color:white;"><?php echo $tbl[$i][2];?></td>
                        <td style="background-color:white;"><?php echo $tbl[$i][3];?></td>
                        <td style="background-color:white;"><?php echo $tbl[$i][4];?></td>
                        <td style="background-color:white;"><?php echo $tbl[$i][5];?></td>
				<td style="background-color:white;"><img src="<?php echo $tbl[$i][6];?>"  height="50" width="50"></td>
                        
						
					<?php 
					}
                    }
					?>
					</tbody>
				
				</table>
		
	<!--user-->
