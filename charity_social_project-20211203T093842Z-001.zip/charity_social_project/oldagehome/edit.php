<?php
session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");
?>
<?php include("top.php");?>
<html>
<head>
<script src="maha.js"></script>
<style>
       
input,textarea,select{
                border: 2px solid white;
             border-radius: 4px;
             width: 100%;
           
    color: black;
            }
            label{
                color: white;
                font-size: 20px;
               
            }
            table{
                padding-bottom:1em;
                width: 500px;
                height: 200px;
            }
            .div1 {
    border-radius: 5px;
    background-color: #f2f2f2;
    margin: auto;
   padding: 30px;
    width:50%;
}
input[type=submit],input[type=reset] {
    background-color: tomato;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
    width:100px;
}

input[type=submit]:hover,input[type=reset]:hover {
    background-color: #ac2925;
   
}
.card{
  background: rgba(0,0,0,0.8);
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.9);
  width:700px;
    height:650px;
  margin: auto;
    
  text-align: center;
  font-family: arial;
    
}



body{
        background-image: url("images/5.jpg") ;
        background-size: cover;
        background-repeat: no-repeat;
        height: 1000px;    
    }
</style>
</head>

<?php
$sql="select * from organisation where org_mail='$user'";
$tbl=getDatas($sql);

for($i=0;$i<count($tbl);$i++)
		{
			
			for($j=0;$j<count($tbl[$i]);$j++)
			{
			
			}
		
?>
<body>
    <br>
    <br>
<div id="err" style="color: red;height: 20px"></div>
    <div class="card">
        <div class="w3_login">
            <h1 style="position: relative;top:150px;color:red"><b>Edit Profile</b></h1>
            <form action="" method="post" >
            <table style="position: relative;left:80px;top:180px">
                <tr>
                    <td>
                        <label> Name</label>
                    </td>
                    <td>
                     <input type="text" name="name" value="<?php echo $tbl[$i][1];?>" onkeypress="return verifyText(event,'err')"/>
                    </td>
                </tr>
                <tr><td></td></tr>
                <tr>
                    <td>
                        <label>Phone Number:</label>
                    </td>
                    <td>
                         <input type="text" name="phn" value="<?php echo $tbl[$i][8];?>" onkeypress="return verifyPhone(this,event,'err')" onblur="return varifyLength(this,'err',10,10);"/>
                    </td>
                </tr>
                <tr><td></td></tr>
                <tr>
                    <td>
                        <label>City:</label>
                    </td>
                    <td>
                          <input type="text" name="city" value="<?php echo $tbl[$i][3];?>"/>
                     </td>
                </tr>
                <tr><td></td><td>
                <tr>
                    <td>
                        <label>District:</label>
                    </td>
                    <td>
                          <input type="text" name="dis" value="<?php echo $tbl[$i][4];?>"/>
                    </td>
                </tr>
                    
                <div style="position:relative;top:450px;left:-350px;">
				    <input type="submit" value="UPDATE"/>
                </div>
                <div style="position:relative;top:450px;left:-100px;">
                    <input type="reset" value="CANCEL"/>
                </div>
            </table>
            </form>
        <div class="clearfix"></div>
                </div>
</div>	
</div>
</body>
</html>		

<?php
		}
		
		if(isset($_POST['name'])){
		
		$a=$_POST['name'];
		
		$c=$_POST['phn'];
		$d=$_POST['city'];
		$e=$_POST['district'];
		
		$sql="update organisation set org_name='$a',org_phno='$c',org_city='$d',org_district='$e' where org_mail='$user'";
		setDatas($sql);
		msgbox("updated");
		}
		
		?>
    