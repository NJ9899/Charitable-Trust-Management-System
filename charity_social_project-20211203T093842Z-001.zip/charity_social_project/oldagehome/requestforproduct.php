<?php session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>
<HTML>
<HEAD>
<TITLE>PRODUCT REQUEST</TITLE>
<STYLE>
LABEL
{
	COLOR:white;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=EMAIL],[TYPE=PASSWORD],[TYPE=DATE],TEXTAREA,select
{
	BORDER-RADIUS:4PX;
	color: black;
	background-color:white;
	height:40px;
	width:290px;
	BORDER:1PX SOLID blue;
}
input[type=submit],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	width:70px;
	height:30px;
}
input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red
}

H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
}
TR
{
	HEIGHT:50PX;
}
    .card{
  background: rgba(0,0,0,0.8);
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.9);
  width:800px;
    height:600px;
  margin: auto;
        top:50PX;
        
   left:800px;
  text-align: center;
  font-family: arial;
    
}



body{
        background-image: url("images/5.jpg") ;
        background-size: cover;
        background-repeat: no-repeat;
        height: 1000px;

       
        
    }
.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
}
	</STYLE>
    <script src="maha.js"></script>
</HEAD>
<?php
$sql="select ifnull(max(product_id),0)+1 from req_product";
$tbl=getDatas($sql);
$sql="select org_name,org_phno from organisation where org_mail='$user'";
$tbl=getDatas($sql);
$p=$tbl[0][0];
$q=$tbl[0][1];
    
?>
    
<BODY>
    
    <div style="POSITION:RELATIVE;LEFT:50PX;top:20px;background-color:white;width:190px;"><a href="view_product_request.php"><font style="color:black;"><b>View Product Request</b></font></a></div>
    <br>
    <br>
<div class="card">
 <br>   
 <br>   
<b><H1 STYLE="POSITION:RELATIVE;LEFT:10x;TOP:25px;color:red;">REQUEST FOR PRODUCT</H1></b>
    <div id="err" style="color: red;height: 20px"></div>
<FORM action="" method="post">
<TABLE STYLE="POSITION:RELATIVE;LEFT:150px;TOP:-40PX">

<TR>
	<TD><LABEL><B>ORGANIZATION NAME:</B></LABEL></TD>
	<TD><b><input type="TEXT" name="oname" value="<?php echo $p ;?>"   readonly></b></TD>
</TR>

<TR>
	<TD><LABEL><B>PHONE NO:</B></LABEL></TD>
	<TD><b><input type="TEXT" name="ophno" value="<?php echo $q ;?>" readonly></b></TD>
</TR>
<TR>
	<TD><LABEL><B>EMAIL:</B></LABEL></TD>
	<TD><b><input type="EMAIL" NAME="email" value="<?php echo $user;?>" readonly></b></TD>
</TR>
 
 <TR>
     <TD><LABEL><B>MATERIALS REQUIRED:</B></LABEL></TD>
	 <TD><b><SELECT name="category">
	       <OPTION VALUE="select">SELECT THE ITEM</OPTION>
	       <OPTION VALUE="educationmat">EDUCATION MATERIALS</OPTION>
	       <OPTION VALUE="clothes">CLOTHES</OPTION>
         </SELECT>
         </b>         
	 </TD>
</TR>
     
<TR>
	<TD><LABEL><B>TIME LIMIT:</B></LABEL></TD>
	<TD><b><input type="date" NAME="timelimit" REQUIRED=" "></b></TD>
</TR>
<tr><br><br><br></tr>
    
<div style="position:relative;top:300px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<INPUT TYPE="submit" NAME="submit" VALUE="SUBMIT"/>
	&nbsp;<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"/></div>

</TABLE>
</FORM>

        </div>
</BODY>
</HTML>
     
<?php
if(isset($_POST['oname']))
{
//$a=$tbl[0][0];
$b=$_POST['oname'];
echo $b;
$c=$_POST['category'];
    echo $c;
$d=$_POST['timelimit'];
    $sql="insert into req_product values('$tbl[0][0]','$user','$p','$c','$d','$q','oldagehome','active')";
setDatas($sql);
    msgbox('Successfully submitted');
    }
    ?>