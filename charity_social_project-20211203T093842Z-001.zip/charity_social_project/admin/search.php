<?php
session_start();
$user=$_SESSION['userid'];

?>
<?php include("top.php");?>
<br><br><br><br><br><br><br><br><br><br><br>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}
table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color:white;
    color: black;
    height: 50px;
}
tr{
    height: 70px;
    border-bottom: 1px solid #ddd;
}
body {
        background-repeat: no-repeat;
background-image: url("bk2.jpg");
        background-size: 1362px;
      }
        .card{
  box-sizing: border-box;
        background: rgba(0,0,0,0.7);
        top:150px;
            left: 200px;
  width:950px;
    height:300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}
    td,h1
    {
        color: white;
    }
    .s:link, .aa:visited {
  background-color: #ccc;
  color: red;
  padding: 10px 14px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

/* Create four equal columns that floats next to each other */
.column {
  float: left;
  width: 25%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
 
}
   
    input[type=text]{
        border: none;
        border-radius: 4px;
        width: 350px;
        height: 50px;
        background-color:beige;
    }
    input[Type=submit]{
        border: none;
        border-radius: 50%;
        height: 50px;
        width:50px;
     cursor: pointer;
        background: green;
        color: white;
    }
    input[type=submit]:hover{
        background-color: darkgreen;
    }
</style>
</head>
<div style="position:relative;top:-100px;left:250px">
<form action="" method="post">
<table>
    <tr>
       
        <input type="text" name="search" placeholder="      search here........" />
        <input type="submit" value="ok"/>
       
    </tr>
    </table>
</form>
</div>
<div style="position:relative;top:-250px;right:100px;">
 
<?php
if(isset($_POST['search']))
{
    $s=$_POST[search];
    
$sql="select * from add_product where prdt_name like '$s%'";
    $tbl=getDatas($sql);
    if($tbl==null){
       
        echo "<div style='position:relative;top:250px;left:420px;'><font color='red'>Not Available.....</font></div>";
    }
    else
    {
       
?>
<h1 style="position:relative;left:720px;top:120px;">PRODUCT VIEW</h1>

<div class="card">
<table border="1" style="position:relative;width:900px;left:16px;top:10px;">
<thead>
<tr>
                            <th>PRODUCT ID</th>
                            <th>PRODUCT NAME</th>
                            <th>ORGANISATION ID</th>
                            <th>PRODUCT TYPE</th>
                            <th>PRODUCT IMAGE</th>
                            <th>AMOUNT</th>
                       
      </tr>
</thead>
<?php

for($i=0;$i<count($tbl);$i++)
{
for($j=0;$j<count($tbl[$i]);$j++)
{
}
?>
<tbody><tr >
                        <td><?php echo $tbl[$i][0];?></td>
                        <td><?php echo $tbl[$i][1];?></td>
                        <td><?php echo $tbl[$i][8];?></td>
                        <td><?php echo $tbl[$i][2];?></td>
                        
                        <td><img src="<?php echo $tbl[$i][6];?>"  height="50" width="50"></td>
                        
                        <td><?php echo $tbl[$i][3];?></td>
                        
 

<?php
}
}
}
?>
</tbody>

</table>
</div>
<!--user-->

