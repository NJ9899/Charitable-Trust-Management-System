<?php include_once("../shares/db/mydatabase.inc");?>
 <?php include("top.php"); ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>
	<!--user--->
	<?php
	$msg = "";
	if(isset($_GET['a'])){
		$a = $_GET['a'];
		$mode = $_GET['mode'];
		if($mode=="app"){
			$sql = "update login set status='1' where name='$a'";
					setDatas($sql);

		    nextpage('approve.php');
		}else{
			$sql = "update login set status='0' where name='$a'";
					setDatas($sql);

		}
		msgbox('sucess');
		$msg = mysql_error();
		if(!isset($msg) || $msg==''){
			$msg = "Success !!!";
		}
	}
	
?>
	<div class="checkout-right">
										<h1 style="position:relative;left:420px;top:120px;">STAFF INFORMATION</h1>

				<table border="1" style="position:relative;width:900px;left:160px;top:150px;">
					<thead>
						<tr>
							
							<th> Name</th>
							
							<th>City</th>
                            <th>District</th>
                            <th>Date of Join</th>
                            <th>Email</th>
							<th>phone No</th>
							
						
							
						</tr>
					</thead>
					<?php
					$sql="select * from staff";
					$tbl=getDatas($sql);
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr class="rem1">
						
						<td class="invert"><?php echo $tbl[$i][1];?></td>
						
						<td class="invert"><?php echo $tbl[$i][4];?></td>
						
						<td class="invert"><?php echo $tbl[$i][5];?></td>
						<td class="invert"><?php echo $tbl[$i][3];?>
						
						</td>
					<td class="invert"><?php echo $tbl[$i][8];?></td>
                        <td class="invert"><?php echo $tbl[$i][7];?></td>
						</tr>
					<?php 
					}
					?>
					</tbody>
				
				</table>
			</div>
	<!--user-->
