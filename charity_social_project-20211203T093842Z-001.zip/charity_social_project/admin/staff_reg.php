<?php include_once("../shares/db/mydatabase.inc");
include_once("top.php");
  ?>
<HTML>
<HEAD><TITLE>STAFF REGISTRATION</TITLE>
<style>
LABEL
{
	COLOR:red;
}
INPUT[TYPE=TEXT],[TYPE=DATE],[TYPE=EMAIL],[TYPE=password]
{
	border-radius:4px;
	width:300px;
	height:40px;
}
INPUT[TYPE=SUBMIT],INPUT[TYPE=RESET]
{
	background-color:tomato;
	color:white;
	border:none;
	border-radius:30px;
	height:30px;
	width:80px;
	font-weight:bold;
	margin-right:20px;
	margin-top:20px;
	position:relative;
	left:200px;
}
INPUT[TYPE=SUBMIT]:HOVER,INPUT[TYPE=RESET]:HOVER
{
	background-color:red;
}
H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
}
TR
{
	HEIGHT:50PX;
}
.CONTAINER
{

	BACKGROUND-COLOR:white;
	HEIGHT:590;
}
	</STYLE>
    <script src="maha.js"></script>

</HEAD>
    
    
<!-- back button disable -->           
<script type="text/javascript">
       history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});
    </script>
 <!-- //back button disable --> 
    
    
 <?php
$sql="select ifnull(max(staff_id),0)+1 from staff";
$tbl=getDatas($sql);

?>   
<BODY BACKGROUND-COLOR="ORANGE">
    
<DIV CLASS="CONTAINER">
    
<H1>STAFF REGISTRATION</H1>
<FORM action="" method="post">
<TABLE STYLE="POSITION:RELATIVE;LEFT:350PX;TOP:25PX">

<TR>
	<TD><LABEL><B>STAFF NAME:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="sname" onkeypress="return verifyText(event,'err')" required></TD>
</TR>
<TR>
	<TD><LABEL><B>DATE OF BIRTH</B></LABEL></TD>
	<TD><INPUT TYPE="DATE" NAME="dob"></TD>
</TR>
<TR>
	<TD><LABEL><B>JOIN DATE</B></LABEL></TD>
	<TD><INPUT TYPE="DATE" NAME="sjd"></TD>
</TR>
<TR>
<td>
<label><b>CITY:</b></label></td>
<td><input type="text" name="city" onkeypress="return verifyText(event,'err')" required></td></tr>
<tr>
<td>
<label><b>DISTRICT:</b></label></td>
<td><input type="text" name="dis" onkeypress="return verifyText(event,'err')" required></td></tr>

<TR>	
	<TD><LABEL><B>GENDER</B></LABEL></TD>
	<TD><INPUT TYPE="RADIO" NAME="gender" VALUE="male">MALE
	<INPUT TYPE="RADIO" NAME="gender" VALUE="female">FEMALE</TD>
<TR>
	<TD><LABEL><B>PHONE NO:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="sphno" onkeypress="return verifyPhone(this,event,'err')" onblur="return varifyLength(this,'err',10,10);"></TD>
</TR>
<TR>
	<TD><LABEL><B>STAFF EMAIL:</B></LABEL></TD>
	<TD><INPUT TYPE="EMAIL" NAME="semail"></TD>
</TR>
<tr>
<td>
<label><b>PASSWORD:</b></label></td> 
<td><input type="password" name="password" required="" onkeypress="return verifyText(event,'err')"></td></tr>
    
<tr>
<td>
<label><b>CONFIRM PASSWORD:</b></label></td> 
<td><input type="password" name="cpwd" required="" onkeypress="return verifyText(event,'err')"></td></tr>
    

<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><INPUT TYPE="SUBMIT" NAME="submit" VALUE="SUBMIT">
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"></TD>
</TR>

</TABLE>
</FORM> 
</DIV>
</BODY>
    </HTML>

<?php
if(isset($_POST['sname']))
{

$b=$_POST['sname'];

$c=$_POST['dob'];
$d=$_POST['sjd'];
$e=$_POST['city'];
$f=$_POST['dis'];
$g=$_POST['gender'];
$h=$_POST['sphno'];
$i=$_POST['semail'];
$j=$_POST['password'];
$k=$_POST['cpwd'];

    
$sql="select staff_email from staff where staff_mail='$i'";
$tbl=getDatas($sql);
    $eml=$tbl[0][0];
if($j!=$k)
{
        msgbox('Password missmatch');
}
elseif($eml<0)
{ 
$sql="select ifnull(max(staff_id),0)+1 from staff";
$tbl=getDatas($sql);
    
$sql="insert into staff values('$tbl[0][0]','$b','$c','$d','$e','$f','$g','$h','$i')";
setDatas($sql);
$sql="insert into login values('$i','$j','staff','1')";
		setDatas($sql);
		msgbox('Successfully registerd');
    nextpage('login.php');
}
else
{
  msgbox('This email id already exists');
}
}

?>

	