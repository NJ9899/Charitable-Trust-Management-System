<?php
include('top.php');
include_once('../shares/db/mydatabase.inc');
?>

<html>
<head>
<style>

th{
height: 40px;
background-color: brown;
color: white;
}
</style>
    </head>
    <br><br><br><br><br><br><br>
    <body>
    <div style="position:relative;left:520px;top:0px;border:groove;width:500px;height:150px;" >
    <form method="post">
<table style="position:relative;top:20px;left:40px;height:100px;width:400px;">
        <tr><td><font color="red">FROM:</font> </td>
<td><input type="date" name="txtStartDate"></td>
</tr>
<tr><td> <font color="red">TO:</font></td>
<td> <input type="date" name="txtEndDate"></td>
</tr>
      <tr>
<td><input type="submit" name="search" value="search product"></td>
</tr>
       </table>
</form>
</div>
        <?php
if(isset($_POST['search']))
{
    $txtStartDate=$_POST['txtStartDate'];
    $txtEndDate=$_POST['txtEndDate'];
//echo $txtStartDate;

    $query="select * from tbl_order where order_date between'$txtStartDate'and'$txtEndDate'order by order_date";
    $tbl=getDatas($query);
   
if($tbl==null){
msgbox("NO VALUES");
}
else{
        ?>
  
        <br>
        <br>
<img src="images/1.jpg" height="150" width="200" style="position:relative;left:200px;">
<div style="position:relative;top:-120px;left:450px;"><b>Nirvana charitable trust<br>
							Kakkanad,Ernakulam<br>
							682030<br>
							Telephone : +91 9447803022<br>
							Email : <a class="mail" href="mailto:mail@example.com">nirvana@gmail.com</a></b></div>
<center>
<h1 style="position:relative;left:0px;top:10px;">ORDER REPORT</h1>
<table border="1" style="position:relative;width:1200px;left:0px;top:50px;">
<thead>
<tr>
                            <th>PRODUCT</th>
                            <th>PRODUCT NAME</th>
                            <th>ORGANIZATION</th>
                            <th>CUSTOMER EMAIL</th>
                            <th>ORDER DATE</th>
                           
      </tr>
</thead>
<?php

for($i=0;$i<count($tbl);$i++)
{
for($j=0;$j<count($tbl[$i]);$j++)
{
}
?>
<tbody><tr >
<td><img src="<?php echo $tbl[$i][9];?>"  width="75" height="75"/></td>
<td><?php echo $tbl[$i][3];?></td>
                        <td><?php echo $tbl[$i][4];?></td>
                        <td><?php echo $tbl[$i][2];?></td>
                        <td><?php echo $tbl[$i][5];?></td>
                       
                        
                       

<?php
}
}
}
?>
       
</body>  
</html>