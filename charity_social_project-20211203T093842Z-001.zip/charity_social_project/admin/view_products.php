<?php include_once("../shares/db/mydatabase.inc");
include_once("top.php");
  ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>
<?php
if(isset($_GET['mode']))
{

 $m=$_GET['mode'];
 //echo $m;
 if($m=="orphange")
{
		$sql="select * from add_product where category='$m'";

}
else if($m=="oldagehome")
{
				$sql="select * from add_product where category='$m'";


}
  
else{
				$sql="select * from add_product where category='$m'";


}
	$tbl=getDatas($sql);
			$msg = mysql_error();
			if(!isset($msg) || $msg==''){
			$msg = "Success !!!";
		}
}
?>


	<!--user--->
	
	

	
										<h1 style="position:relative;left:420px;top:120px;">PRODUCT VIEW</h1>

				<table border="1" style="position:relative;width:900px;left:160px;top:150px;">
					<thead>
						<tr>
							<th>PRODUCT ID</th>
                            <th>PRODUCT NAME</th>
                            <th>PRODUCT TYPE</th>
                            <th>PRICE</th>
                             <th>AVAILABLE STOCK</th>
                            <th>DATE</th>
                            <th>PRODUCT IMAGE</th>
                           
				       </tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr >
						<td><?php echo $tbl[$i][0];?></td>
						<td><?php echo $tbl[$i][1];?></td>
                        <td><?php echo $tbl[$i][2];?></td>
                        <td><?php echo $tbl[$i][3];?></td>
                        <td><?php echo $tbl[$i][4];?></td>
                        <td><?php echo $tbl[$i][5];?></td>
				<td><img src="<?php echo $tbl[$i][6];?>"  height="50" width="50"></td>
                        
						
					<?php 
					}
					?>
					</tbody>
				
				</table>
		
	<!--user-->
