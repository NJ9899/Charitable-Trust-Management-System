<?php
session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");
include("top.php"); ?>

<html>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
    text-align: center;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;  
    text-align: center;
}
.card{
  background: rgba(0,0,0,0.8);
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.9);
  width:700px;
    height:800px;
  margin: auto;
    
  text-align: center;
  font-family: arial;
    
}



body{
        background-image: url("images/2.jpg") ;
        background-size: cover;
        background-repeat: no-repeat;
        height: 1000px;    
    }
    </style>
 </head>



<?php
date_default_timezone_set('Asia/Calcutta');
$date1 = date("m/d/y");// current date
 $sql="select fund_id from req_fund where org_mail='$user'";
 $tbl=getDatas($sql);
 $p=$tbl[0][0];
    
 $sql="select * from payment_donation where fund_id='$p'";

	$tbl=getDatas($sql);
					if($tbl==null){
						echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>No Donations Received...</font></div>";

					}
					else
					{

?>

	<!--user--->

	<div class="checkout-right">
					<h1 style="position:relative;left:500px;top:100px;color:white;"><b>RECEIVED DONATIONS</b></h1>
				<table border="1" style="position:relative;width:900px;left:200px;top:150px">
					<thead>
						<tr>
							<th>CUSTOMER EMAIL</th>
							<th>AMOUNT RECEIVED</th>
                            <th>DATE</th>
							
							
							
							
						</tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr class="rem1">
						
                        
                        <td class="invert" style="background-color:white;"><?php echo $tbl[$i][2];?></td>
                        <td class="invert" style="background-color:white;"><?php echo $tbl[$i][3];?></td>
						<td class="invert" style="background-color:white;"><?php echo $tbl[$i][4];?></td>
                        
						
					<?php 
					}
                    }
					?>
					</tbody>
				
				</table>
			</div>
	<!--user-->
        
     </html>
        
            
        
        