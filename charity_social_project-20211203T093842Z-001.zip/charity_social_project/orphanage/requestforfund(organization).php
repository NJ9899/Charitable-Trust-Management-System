<?php session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>
<HTML>
<HEAD>
<TITLE>FUND REQUEST</TITLE>
<STYLE>
LABEL
{
	COLOR:white;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=EMAIL],[TYPE=PASSWORD],[TYPE=DATE],TEXTAREA
{
	BORDER-RADIUS:4PX;
	color:black;
	background-color:white;
	height:40px;
	width:290px;
	BORDER:1PX SOLID blue;
}
input[type=submit],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	width:70px;
	height:30px;
}
input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red
}
H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
}
TR
{
	HEIGHT:50PX;
}

.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
}
    .card{
  background: rgba(0,0,0,0.8);
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.9);
  width:700px;
    height:800px;
  margin: auto;
    
  text-align: center;
  font-family: arial;
    
}



body{
        background-image: url("images/2.jpg") ;
        background-size: cover;
        background-repeat: no-repeat;
        height: 1000px;

       
        
    }
	</STYLE>
    <script src="maha.js"></script>
</HEAD>
<?php
$sql="select ifnull(max(fund_id),0)+1 from req_fund";
$tbl=getDatas($sql);
$sql="select org_name,org_phno from organisation where org_mail='$user'";
$tbl=getDatas($sql);
$p=$tbl[0][0];
$q=$tbl[0][1];
    
?>
<BODY>
    <div style="POSITION:RELATIVE;LEFT:100PX;top:20px;background-color:white;width:190px;"><a href="view_fund_request.php"><font style="color:black;"><b>View Fund Request</b></font></a></div>
    <br>
    <br>
    <div class="card">
        
<H1 STYLE="POSITION:RELATIVE;LEFT:150;TOP:25PX;color:red;">REQUEST FOR FUND</H1>
    <div id="err" style="color: red;height: 20px"></div>
    
<FORM action="" method="post">
<TABLE STYLE="POSITION:RELATIVE;LEFT:150PX;TOP:25PX">

<TR>
	<TD><LABEL><B>ORGANIZATION NAME:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="oname" value="<?php echo $p ;?>" readonly/></TD>
</TR>

<TR>
	<TD><LABEL><B>PHONE NO:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="ophno" value="<?php echo $q ;?>" onkeypress="return verifyPhone(this,event,'err')" onblur="return varifyLength(this,'err',10,10);" readonly/></TD>
</TR>
<TR>
	<TD><LABEL><B>EMAIL:</B></LABEL></TD>
	<TD><INPUT TYPE="EMAIL" NAME="email" value="<?php echo $user;?>" readonly//></TD>
</TR>
<TR>
     <TD><LABEL><B>NEEDED AMOUNT:</B></LABEL></TD>
	 <TD><INPUT TYPE="TEXT" NAME="amt" REQUIRED=" "//></TD>
</TR>
<TR>
     <TD><LABEL><B>PURPOSE:</B></LABEL></TD>
<TD><textarea rows=""cols="" NAME="pur"  onkeypress="return verifyText(event,'err')"REQUIRED=" " ></textarea></TD>
</TR>
<TR>
     <TD><LABEL><B>ACCOUNT NUMBER:</B></LABEL></TD>
	 <TD><INPUT TYPE="text" NAME="acc" REQUIRED=" "/></TD>
</TR>
<TR>
     <TD><LABEL><B>IFSC CODE:</B></LABEL></TD>
	 <TD><INPUT TYPE="text" NAME="ifsc" REQUIRED=" "/></TD>
</TR>
<TR>
     <TD><LABEL><B>TIME LIMIT:</B></LABEL></TD>
	 <TD><INPUT TYPE="date" NAME="time" REQUIRED=" "/></TD>
</TR>
    
<div style="position:relative;top:500px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<INPUT TYPE="submit" NAME="submit" VALUE="SUBMIT"/>
	&nbsp;<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"/></div>
</TABLE>
</FORM>

    </div>
</BODY>
</HTML>
    <?php
if(isset($_POST['oname']))
{
//$a=$tbl[0][0];
$b=$_POST['oname'];
//echo $b;
$c=$_POST['amt'];
    //echo $c;
$d=$_POST['time'];
$e=$_POST['pur'];
$f=$_POST['acc'];
$g=$_POST['ifsc'];
    $sql="insert into req_fund values('$tbl[0][0]','$user','$p','$c','$e','$f','$g','$d','$q','orphanage','active')";
setDatas($sql);
    msgbox('Successfully submitted');
    }
    ?>