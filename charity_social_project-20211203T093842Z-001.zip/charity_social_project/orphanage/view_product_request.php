<?php
session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");?>
 <?php include("top.php"); ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
    td,th{
    
    text-align: center;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}
.card{
  background: rgba(0,0,0,0.8);
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.9);
  width:700px;
    height:800px;
  margin: auto;
    
  text-align: center;
  font-family: arial;
    
}



body{
        background-image: url("images/2.jpg") ;
        background-size: cover;
        background-repeat: no-repeat;
        height: 1000px;    
    }
    </style>
 </head>
	<!--user--->
	<?php
	$sql="select * from req_product where org_mail='$user' ";
					$tbl=getDatas($sql);
					if($tbl==null){
						echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>No Requests...</font></div>";

					}
					else
					{
?>
	<div class="checkout-right">
					<h1 style="position:relative;left:520px;top:100px;color:white;"><b>FUND REQUEST VIEW</b></h1>
				<table border="1" style="position:relative;width:900px;left:150px;top:150px">
					<thead>
						<tr>
							
							<th>Materials</th>
                            <th>Target Date</th>
                            <th>Delete</th>
							
							
							
							
						</tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr class="rem1">
						
                        
                        <td style="background-color:white;" class="invert"><?php echo $tbl[$i][3];?></td>
                        <td style="background-color:white;" class="invert"><?php echo $tbl[$i][4];?></td>
						<td style="background-color:white;" class="invert"> <a href="?a=<?php echo $tbl[$i][0];?>"><font color="green">Delete</font></a></td>
							
						
					
						
					<?php 
					}
					}
					?>
					</tbody>
				
				</table>
			</div>
	<!--user-->
        
     <?php
if(isset($_GET['a']))
{
    $id=$_GET['a'];
    if($id!=null)
    {
        $sql="delete from req_product where product_id='$id'";
        $tbl=setDatas($sql);
        msgbox("Success");
    }
}
?>
        
            
        
        