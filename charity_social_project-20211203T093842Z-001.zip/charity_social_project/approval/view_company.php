<?php include_once("../shares/db/mydatabase.inc");
include_once("top.php");
  ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: brown;
    color: white;
    height: 40px;
				   text-align: center;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>
	<!--user--->
<?php
if(isset($_GET['id'])){
	
	$id=$_GET['id'];
	$m=$_GET['mode'];
	if($m=="app"){
		$sql="update login set status='1' where username='$id'";
		setDatas($sql);
		
	}
	else
	{
		$sql="update login set status='0' where username='$id'";
		setDatas($sql);
	}
}
?>
	
	

	<?php

$sql="select company_reg.*,login.* from company_reg join login on company_reg.email=login.username where login.status='0'";
					$tbl=getDatas($sql);
if($tbl==null){
	echo "<div style='position:relative;top:350px;color:blue;left:620px;'>No New Registrations.........</div>";
}
else
{
?>
										<h1 style="position:relative;left:620px;top:120px;">NEW COMPANY</h1>

				<table border="1" style="position:relative;width:1200px;left:160px;top:150px;">
					<thead>
						<tr>
							<th>Company Name</th>
                            <th>License</th>
                            <th>District</th>
                            <th>City</th>
                            <th>Pincode</th>
                            <th>Mobile</th>
                            
                            <th>Email</th>
                            
                          <th colspan="2">Approval</th>
                         
				       </tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr >
						<td><?php echo $tbl[$i][1];?></td>
						<td><?php echo $tbl[$i][2];?></td>
						<td><?php echo $tbl[$i][3];?>
						<td><?php echo $tbl[$i][4];?>
						<td><?php echo $tbl[$i][5];?>
						<td><?php echo $tbl[$i][6];?>
						<td><?php echo $tbl[$i][7];?>
						
						<td><a href="?id=<?php echo $tbl[$i][7];?>&mode=app">Approved</a></td>
						<td><a href="?id=<?php echo $tbl[$i][7];?>&mode=rej">Rejected</a></td>
						
						</tr>
						
					<?php 
					}
}
					?>
					</tbody>
				
				</table>
		
	<!--user-->
