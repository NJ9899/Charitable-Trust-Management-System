<?php 
session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");
include_once("top.php");
  ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>
<?php





$sql="select org_id from organisation where org_mail='$user'";
            $tbl=getDatas($sql);
$p=$tbl[0][0];
$sql="select * from tbl_order where org_id='$p'";
$tbl=getDatas($sql);



if($tbl==null){
    echo("<div style='position:relative;left:620px;top:250px;color:red;'>No Bookings......</div>");
}
else
{
?>	
										<h1 style="position:relative;left:420px;top:120px;">PRODUCT VIEW</h1>

				<table border="1" style="position:relative;width:900px;left:160px;top:150px;">
					<thead>
						<tr>
							<th>PRODUCT ID</th>
                            <th>BUYER</th>
                            <th>PRODUCT NAME</th>
                            <th>PRICE</th>
                             <th>ORDER DATE</th>
                            <th>PAYMENT METHOD</th>
                            <th>DELIVERY STATUS</th>
                            <th>PRODUCT IMAGE</th>
                           
				       </tr>
					</thead>
					<?php
                    
                    
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr >
						<td style="background-color:white;"><?php echo $tbl[$i][0];?></td>
						<td style="background-color:white;"><?php echo $tbl[$i][2];?></td>
                        <td style="background-color:white;"><?php echo $tbl[$i][3];?></td>
                        <td style="background-color:white;"><?php echo $tbl[$i][4];?></td>
                        <td style="background-color:white;"><?php echo $tbl[$i][5];?></td>
                        <td style="background-color:white;"><?php echo $tbl[$i][7];?></td>
                        <td style="background-color:white;"><?php echo $tbl[$i][8];?></td>
				<td style="background-color:white;"><img src="<?php echo $tbl[$i][9];?>"  height="50" width="50"></td>
                        
						
					<?php 
					}
}
					?>
					</tbody>
				
				</table>
		
	<!--user-->
