<?php session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>
<HTML>
<HEAD>
<TITLE>PRODUCT REQUEST</TITLE>
<STYLE>
LABEL
{
	COLOR:black;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=EMAIL],[TYPE=PASSWORD],[TYPE=DATE],TEXTAREA,select
{
	BORDER-RADIUS:4PX;
	color:black;
	background-color:white;
	height:40px;
	width:290px;
	BORDER:1PX SOLID blue;
}
input[type=submit],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	width:70px;
	height:30px;
}
input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red
}

H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
}
TR
{
	HEIGHT:50PX;
}
.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
}
	</STYLE>
    <script src="maha.js"></script>
</HEAD>
<?php
$sql="select ifnull(max(product_id),0)+1 from req_product";
$tbl=getDatas($sql);
$sql="select org_name,org_phno from organisation where org_mail='$user'";
$tbl=getDatas($sql);
$p=$tbl[0][0];
$q=$tbl[0][1];
    
?>
    <br><br><br><br><br>
<BODY>
    <a href="view_product_request.php">View Product Request</a>
<DIV CLASS="CONTAINER">
<H1>REQUEST FOR PRODUCT</H1>
    <div id="err" style="color: red;height: 20px"></div>
<FORM action="" method="post">
<TABLE STYLE="POSITION:RELATIVE;LEFT:500PX;TOP:25PX">

<TR>
	<TD><LABEL><B>ORGANIZATION NAME:</B></LABEL></TD>
	<TD><input type="TEXT" name="oname" value="<?php echo $p ;?>"  readonly></TD>
</TR>

<TR>
	<TD><LABEL><B>PHONE NO:</B></LABEL></TD>
	<TD><input type="TEXT" name="ophno" value="<?php echo $q ;?>"  readonly></TD>
</TR>
<TR>
	<TD><LABEL><B>EMAIL:</B></LABEL></TD>
	<TD><input type="EMAIL" NAME="email" value="<?php echo $user;?>" readonly></TD>
</TR>
 
 <TR>
     <TD><LABEL><B>MATERIALS REQUIRED:</B></LABEL></TD>
	 <TD><SELECT name="category">
	       <OPTION VALUE="select">SELECT THE ITEM</OPTION>
	       <OPTION VALUE="educationmat">EDUCATION MATERIALS</OPTION>
	       <OPTION VALUE="clothes">CLOTHES</OPTION>
         </SELECT>
                  
	 </TD>
</TR>
     
<TR>
	<TD><LABEL><B>TIME LIMIT:</B></LABEL></TD>
	<TD><input type="date" NAME="timelimit" REQUIRED=" "></TD>
</TR>

<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><input type="SUBMIT" NAME="submit" VALUE="SUBMIT">
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="RESET"  value="CANCEL"></BR></BR>
        </TD>
</TR>

</TABLE>
</FORM>
</DIV>
</BODY>
</HTML>
     
<?php
if(isset($_POST['oname']))
{
//$a=$tbl[0][0];
$b=$_POST['oname'];

$c=$_POST['category'];
    
$d=$_POST['timelimit'];

    $sql="insert into req_product values('$tbl[0][0]','$user','$p','$c','$d','$q','womenwelfare','active')";
setDatas($sql);
    msgbox('Successfully submitted');
    }
    ?>