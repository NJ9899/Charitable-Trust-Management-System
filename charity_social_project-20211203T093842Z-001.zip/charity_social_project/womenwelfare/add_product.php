<?php 
session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");
include("top.php");
?>
<html>
<head>

    <style>
        
       
input,textarea,select{
                border: 2px solid;
             border-radius: 4px;
             width: 100%;
height:50px;
           
             
            }
            label{
                color: green;                                           
                font-size: 20px;
            }
            table{
                padding-bottom:1em;
                width: 800px;
                height: 600px;
            }
            input[type=submit] {
    background-color: tomato;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
    width:100px;
}

input[type=submit]:hover {
    background-color: #ac2925;
}
          
    </style>
</head>
<body>
<div id="err" style="color: red;height: 20px"></div>

<div class="w3_login">
<h3 style="position: relative;top:130px;left:620px">ADD PRODUCT </h3>

        <form action="" method="post" enctype="multipart/form-data">
            <table style="position: relative;left:190px;top:155px">
                <tr>
                    <td>
                        <label>Product Name</label>
                    </td>
                    <td>
                        <input type="text" name="name" onkeypress="return verifyText(event,'err')"  required="">
                      </td>
                </tr>
           <tr><td></td></tr>
                 
                 <tr>
                    <td>
                         <label>Products</label>
                    </td>
                    <td>
                        <select name="category">
                            <option value=""></option>
<option value="clayproducts">clay products</option>
                            
<option value="pickles">pickles</option>
                            <option value="Fruitjams">fruit jams</option>
                                     </select>
                      </td>
                </tr> <tr><td></td></tr>
              
                

                 <tr>
                    <td>
                        <label>Price per packet</label>
                    </td>
                    <td>
                        <input type="text" name="price" required="">
                      </td>
                </tr> <tr><td></td></tr>
                 <tr>
                    <td>
                        <label> Quantity </label>
                    </td>
                    <td>
                        <input type="text" name="quantity" required="">
                      </td>
                </tr>
                <tr><td></td></tr>
                <tr>
                    <td>
                        <label> Stock Date </label>
                    </td>
                    <td>
                        <input type="date" name="date" required="">
                      </td>
                </tr>
                <tr><td></td><td>
<tr>
                    <td>
                        <label> Product Image </label>
                    </td>
                    <td>
                        <input type="file" name="file" required="">
                        <input type="text" name="cat" value="womenwelfare" hidden>
                      </td>
                </tr>
                <tr><td></td><td>
                        <input type="submit" value="ADD"/>
            </table>
            
            
        </form>
                                   </div>
        <div class="clearfix"></div>
    </body>
    </html>
    
     <?php
$fldr = "../uploads";
	$allowedExts = array("jpg", "gif", "jpeg","mp4");
	$extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
	$f=$_FILES["file"]["name"];
	
	$size = $_FILES["file"]["size"];
	if($_FILES["file"]["size"] > 5000000)
	{
		die("File Size is ".($size/1000000)."MB, Maximum allowed size is 5MB");
	}
	if ((($_FILES["file"]["type"] == "image/jpg")
	|| ($_FILES["file"]["type"] == "image/jpeg")
	|| ($_FILES["file"]["type"] == "image/gif")
	|| ($_FILES["file"]["type"] == "video/mp4"))
	
	&& ($_FILES["file"]["size"] <= 50000000)
	&& in_array($extension, $allowedExts)){
		if ($_FILES["file"]["error"] > 0)
		{
			echo "Return Code: " .$_FILES["file"]["error"]. "<br />";
		}
		else
		{
		if (file_exists("$fldr/" .$_FILES["file"]["name"]))
		{
			echo $_FILES["file"]["name"] . " already exists. ";
		}
		else
		{
			move_uploaded_file($_FILES["file"]["tmp_name"],"$fldr/" . $_FILES["file"]["name"]);
			

			$mv_name = $_FILES["file"]["name"];		
			$mv_type = $_FILES["file"]["type"];
				$fname=$fldr."/".$mv_name;
			$mv_size = $_FILES["file"]["size"];
			
			 $n1=$_POST['name'];
            $n2=$_POST['category'];
			$n3=$_POST['price'];
			$n4=$_POST['quantity'];
			$n5=$_POST['date'];
            $n6=$_POST['cat'];
			//$n6=$_POST['file'];
			
			
			$sql="select org_id from organisation where org_mail='$user'";
            $tbl=getDatas($sql);
             $p=$tbl[0][0];
			$sql="select ifnull(max(owner_id),0)+1 from add_product";
			$tbl=getDatas($sql);
		$sql="insert into add_product values('$tbl[0][0]','$n1','$n2','$n3','$n4','$n5','$fname','$n6','$p')";
		setDatas($sql);
			
			msgbox('successfully uploaded');
		}
		}
	}
?>