<label>ACCOUNT NUMBER</label>
            <input type="text"  name="acc_no" value="<?php echo $tbl[0][5];?>">
            <label>IFSC CODE</label>
            <input type="text" name="ifsc" value="<?php echo $tbl[0][6];?>">
            <label>AMOUNT</label>
            <input type="text" name="amt" required="">
            
            
            
            
<?php 
session_start();
$user=$_SESSION['userid'];
include("top.php");
include_once("../shares/db/mydatabase.inc");?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container2 {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
</head>
<body>
    
    <?php
$sql="select ifnull(max(pay_id),0)+1 from payment_donation";
$tbl=getDatas($sql);
$p=$tbl[0][0];
?>
    
<?php 
    
    if(isset($_GET['id']))
    {
        $id=$_GET['id'];
        $sql="select * from req_fund where fund_id='$id'";
    
	$tbl=getDatas($sql);
        date_default_timezone_set('Asia/Calcutta');
$date1 = date("m/d/y");// current date
    }
    
    
    ?>

<div class="row" style="position:relative;left:520px;top:100px;width:400px;">
  <div class="col-75">
    <div class="container2">
      <form action=" " method=POST>
      
        <div class="row">
         

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label>ACCOUNT HOLDER</label>
            <input type="text"  name="acc_holder" value="<?php echo $tbl[0][2];?>">
              
            <input type="text"  name="id" value="<?php echo $tbl[0][0];?>" hidden>  
             
              <label>QUANTITY</label>
              <input class="billing-address-name form-control" type="text" name="quantity" value="<?php echo $quantity;?>">
              
              <label>TOTAL PRICE</label>
              <input class="billing-address-name form-control" type="text" name="price" value="<?php echo $price;?>">
              
              <label class="control-label">NAME ON CARD</label>
              <input class="billing-address-name form-control" type="text" name="name" >
              
              <label class="control-label">CARD NUMBER</label>
															<input class="number credit-card-number form-control" type="text" name="number"
																		  inputmode="numeric" autocomplete="cc-number" autocompletetype="cc-number" x-autocompletetype="cc-number"
																		  placeholder="&#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149;" pattern="^\d{4}\d{3}\d{3}$" title="must contain 16 numbers">
                 
                 <label>IFSC CODE</label>
                <input type="text" name="ifsc" value="<?php echo $tbl[0][6];?>">
            
              
              <label class="control-label">ORDER DATE</label>
              <input class="expiration-month-and-year form-control" type="text" name="date" value="<?php echo $d;?>">
              
              
            
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="submit" name="submit" value="SUBMIT">&nbsp;&nbsp;&nbsp;
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="reset" name="reset" value="CANCEL">
            
          
        </div>
    

          </div>                                                                       
                                                                           
</form> 
  </div>                                                                        
</div>
</div>
</body>
</html>

<?php
if(isset($_POST['submit']))
{

$c=$_POST['id'];
$d=$_POST['org_name'];
$f=$_POST['amt'];

$sql="insert into payment_donation values('$p','$c','$user','$f','$date1')";
setDatas($sql);
msgBox("Successfully Added");

}

?>















 <?php
 if(isset($_POST['id']))
 {
 $a=$_POST['id'];
//echo $a;
$b=$_POST['radio'];
//echo $b;
 
$sql="select * from add_product where prdt_id='$a'";
$tbl=getDatas($sql);
$stock=$tbl[0][4];
$pname=$tbl[0][1];
//echo "f".$stock;
//$quantity=1;
$price=$tbl[0][3];
$img=$tbl[0][6];
$org_id=$tbl[0][8];
     $sql="select cust_id from customer where cust_email='$user'";
     $tbl=getDatas($sql);
     $id1=$tbl[0][0];
     echo $id1;
     date_default_timezone_set('Asia/Calcutta');
$date1 = date("Y-m-d");// current date
$d = date("Y-m-d");
		$s=strtotime("+10 day");
       $k=date("Y-m-d", $s);
$balstock=$stock-1;
$sql="select ifnull(max(order_id),0)+1 from tbl_order";
	$tbl=getDatas($sql);
	$oid=$tbl[0][0];
	//echo "orderid------".$oid;
if($stock<=0){
					echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>Sorry No Stock available...</font></div>";
		}
		else
		{
		
		$sql="update add_product set qty='$balstock' where prdt_id='$a'";
		setDatas($sql);
	

if($b=="credit"){
	?>
<h3 style="position:relative;left:620px;top:130px;">CARD Info.  </h3>
    	<div class="div1"  style="position:relative;top:150px;">
        <form action="card.php" method="post">
           
            <table style="position: relative;left:10px;top:10px">
                <tr>
                    <td>
                        <label>  Card Number</label>
                    </td>
                    <td>
                        <input type="text" name="cno" required />
						<input type="text" name="id" value="<?php echo $a;?>" hidden required />
                      </td>
                </tr>
                      
		   </td></tr>
                 
                   <tr>
                    <td>
                        <label> Password</label>
                    </td>
                    <td>
                        <input type="password" name="pass" required onkeypress="return verifyText(event,'err')" />
                      </td>
                </tr>
           <tr><td></td></tr>                    
				<tr><td></td><td><input type="submit" value="verify"/></td></tr>
            </table>
            
            
        </form></div>

 
<?php
}
 else{
	 
	$sql="insert into tbl_order values('$oid','$a','$user','$pname','$price','$date1','$d','$k','cod','processing','$img','$org_id')";
	       setDatas($sql);
	
     echo "
		    <div style='position:relative;left:450px;top:120px;'>
			<font color='red'>Buyer Name:</font>$user<br>
			<font color='red'>Product:</font>$pname<br>
			
			<font color='red'>Price:</font>$price<br>
			<font color='red'>Expected Delivery:</font>$k<br>
			<font color='red'>Order Date:</font>$d<br>
			we will get back to you shortly!!!!! Thank You.
			</div>
		";
	
 }
 
 }
 }

?>














    
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           

                                                                           
                                                                           
                                                                           