<?php include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>

<HTML>
<HEAD><TITLE>ADD ORGANISATION</TITLE>
<style>
LABEL
{
	COLOR:darkmagenta;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=DATE],[TYPE=EMAIL],[TYPE=PASSWORD],SELECT,TEXTAREA
{
	BORDER-RADIUS:4PX;
	color:black;
	BACKGROUND-COLOR:#CCC;
	height:25px;
	width:290px;
	BORDER:1px solid red;
}

INPUT[TYPE=SUBMIT]
{
	background-color:tomato;
	color:white;
	border:none;
	border-radius:30px;
	height:30px;
	width:80px;
	font-weight:bold;
	margin-right:20px;
	margin-top:20px;
	position:relative;
	left:200px;
}
H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
	position:relative;
	left:100px;
}
TR
{
	HEIGHT:50PX;
}
.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
}
	</STYLE>
</HEAD>
    <?php
$sql="select ifnull(max(org_id),0)+1 from organisation";
    $tbl=getDatas($sql);

?>
<BODY>
<DIV CLASS="CONTAINER">
<H1>ADD ORGANISATION</H1>
<FORM action="" method="post">
<TABLE STYLE="POSITION:RELATIVE;LEFT:500PX;TOP:25PX">
<TR>
	<TD><LABEL><B>ORGANISATION ID:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="oid" value="<?php echo $tbl[0][0];?>" readonly></TD>
</TR>
<TR>
	<TD><LABEL><B>ORGANISATION NAME:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="oname" REQUIRED=" "></TD>
</TR>
<tr>
<TD><LABEL><B>CATEGORY:</B></LABEL></TD>
<td><select name="category">
<option>--Select category--</option>
<option value="orphanage">ORPHANAGE</option>
<option value="women's welfare">WOMEN'S WELFARE</option>
<option value="old age home">OLD AGE HOME</option></td>
</tr>
<TR>
	<TD><LABEL><B>CITY:</B></LABEL></TD>
	<TD><input type="text" NAME="city" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>DISTRICT:</B></LABEL></TD>
	<TD><input type="text" NAME="district" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>PINCODE:</B></LABEL></TD>
	<TD><input type="text" NAME="pin" REQUIRED=" "></TD>
</TR>

<TR>	
	<TD><LABEL><B>REGISTRATION NO:</B></LABEL></TD>
	<TD><INPUT TYPE="FILE" NAME="reg" REQUIRED=" "></TD>
    
<TR>
	<TD><LABEL><B>ORGANIZATION EMAIL:</B></LABEL></TD>
	<TD><input type="text" NAME="email" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>PHONE NO:</B></LABEL></TD>
	<TD><INPUT TYPE="TEXT" NAME="ophno" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>PERSON OF CONTACT</B></LABEL></TD>
	<TD><input type="text" NAME="poc" REQUIRED=" "></TD>
</TR>
<TR>
	<TD><LABEL><B>PERSON OF CONTACT PHONE NO:</B></LABEL></TD>
	<TD><input type="text" NAME="pocno" REQUIRED=" "></TD>
</TR>

<TR>
	<TD><LABEL><B>PASSWORD:</B></LABEL></TD>
	<TD><INPUT TYPE="PASSWORD" NAME="opass" REQUIRED=" "onkeypress="return verifyText(event,'err')"></TD>
</TR>
<tr>
<td>
<label>CONFIRM PASSWORD:</label></td> 
<td><input type="password" name="cpwd" required="" onkeypress="return verifyText(event,'err')"></td></tr>
    

<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><INPUT TYPE="SUBMIT" NAME="submit2" VALUE="ADD">
	</TD>
</TR>

</TABLE>
</FORM>
</DIV>
</BODY>
<HTML>
<?php
if(isset($_POST['oid']))
{
$a=$_POST['oid'];
echo $a;
$b=$_POST['oname'];
echo $b;
$c=$_POST['category'];
$d=$_POST['city'];
$e=$_POST['district'];
$f=$_POST['pin'];
$g=$_POST['reg'];
$h=$_POST['email'];
$i=$_POST['ophno'];
$j=$_POST['poc'];
$k=$_POST['pocno'];
$l=$_POST['opass'];
$m=$_POST['cpwd'];
if($l==$m)
{
$sql="insert into organisation values('$a','$b','$c','$d','$e','$f','$g','$h','$i','$j','$k')";
setDatas($sql);
$sql="insert into login values('$h','$l','organisation','1')";
		setDatas($sql);
		msgbox('Successfully registerd');
}
else
{
  echo "password missmatch";
}
}

?>



	