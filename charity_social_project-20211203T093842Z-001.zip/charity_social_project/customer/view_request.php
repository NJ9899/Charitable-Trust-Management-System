<?php

include_once("../shares/db/mydatabase.inc");?>
 <?php include("top.php"); ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>



<?php
if(isset($_GET['mode']))
{

 $m=$_GET['mode'];
 //echo $m;
 if($m=="orphange")
{
		$sql="select * from organisation where category='$m'";

}
else if($m=="oldagehome")
{
				$sql="select * from organisation where category='$m'";


}
  
else{
				$sql="select * from organisation where category='$m'";


}
	$tbl=getDatas($sql);
					if($tbl==null){
						echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>No Requests...</font></div>";

					}
					else
					{
}
?>

	<!--user--->

	<div class="checkout-right">
					<h1 style="position:relative;left:520px;top:100px;">PRODUCT REQUEST VIEW</h1>
				<table border="1" style="position:relative;width:900px;left:150px;top:150px">
					<thead>
						<tr>
							<th>Organisation Name</th>
                            <th>Phone No</th>
                            <th>Fund Request</th>
                            <th>Product Request</th>
							
							
							
							
						</tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr class="rem1">
						
                        
                        <td class="invert"><?php echo $tbl[$i][1];?></td>
                        <td class="invert"><?php echo $tbl[$i][8];?></td>
                        <td><a href="view_fund_req.php?id=<?php echo $tbl[$i][7];?>">Fund</a></td>
                        <td><a href="view_prod_req.php?id=<?php echo $tbl[$i][7];?>">Product</a></td>
                        </tr>
						
					<?php 
					}
					}
					?>
					</tbody>
				
				</table>
			</div>
	<!--user-->
        
     
        
            
        
        