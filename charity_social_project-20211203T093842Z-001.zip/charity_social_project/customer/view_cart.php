<?php session_start();
$user=$_SESSION['userid'];
 include_once("../shares/db/mydatabase.inc");?>
<?php include("top.php");?>


<html>
<head>
<style>
  
   
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid black;
  padding: 8px;
}

#customers tr:nth-child(even){
    color: white;
    background-color:brown;}

#customers tr:hover {background-color: powderblue;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color:brown;
  color: white;
}
  s2
    {
        color: red;
    }
    body
    {
        background-image: url(p5.jpg);
        background-size: 1370px;
        background-repeat: no-repeat;
    }
    h3
    {
        color:black;
        font-size: 40px;
    }
    
</style>
</head>
<br><br><br><br><br>
<h3 style="position: relative;top:10px;left:450px;"><b>VIEW CART</b> </h3> 
    <br>
    <br>

<?php
$db= " select sum(t_amnt),sum(num) from tbl_cart where buyer='$user' and pay_status='null' ";
$t=getDatas($db);
  if($db==null){
									echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>No Items in the cart ...</font></div>";

}
else
{  
for($i=0;$i<count($t);$i++)
		{
			
			for($j=0;$j<count($t[$i]);$j++)
			{
			
			}
$total= $t[$i][0];
            $number= $t[$i][1];
		}
?>
    <div style="position:relative;left:20px;">
				<center><table id="customers" style="position;relative;top:80px;width:800px;">
					<thead>
						<tr>
							
							<th>PRODUCT</th>
							<th>PRODUCT NAME</th>
                            <th>QUANTITY</th>
                            <th>PRICE</th>
							<th>REMOVE</th>
						</tr>
					</thead>

<?php
$db="select *,sum(t_amnt),sum(num) from tbl_cart where buyer='$user' and pay_status='null'  group by prdt_name";
$tbl=getDatas($db);
for($i=0;$i<count($tbl);$i++)
		{
			
			for($j=0;$j<count($tbl[$i]);$j++)
			{
			
			}
		
			
	?>
	
				<tbody><tr class="rem1">
						<td class="invert-image"><?php echo "<img src='".$tbl[$i][7]."'style='position:relative;width:50px;height:50px;'"?></td>
						<td class="invert"><?php echo $tbl[$i][3];?></td>
						<td class="invert"><?php echo $tbl[$i][11];?></td>
						<td class="invert">
							 <?php echo $tbl[$i][10];?>
						</td>
						<td><a href="rmv_prd.php?id=<?php echo $tbl[$i][0];?>"><font color="red">DELETE</font> </a></td>
						
						</tr>
	
	<?php 
					}
}
					?>
					<tr><td></td><td></td><td>TOTAL</td><td><?php echo $total;?> </td></tr>
                    <tr ><td></td><td></td><td></td><td><a href="confirm.php?tot=<?php echo $total;?> & no=<?php echo $number;?>"><B><font color="black">BUY NOW</font></B></a></td></tr>
					




</tbody>
			
                    
                    </table></center>
			

