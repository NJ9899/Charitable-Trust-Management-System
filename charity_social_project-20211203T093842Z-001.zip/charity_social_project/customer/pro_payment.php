<?php session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");
?>
<?php include("top.php"); ?>

<head>
<style>
 .aa:link, .aa:visited {
  background-color: #f44336;
  color: white;
  padding: 20px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

.aa:hover, .aa:active {
  background-color: red;
}
        
input,textarea,select{
                border: 2px solid;
             border-radius: 4px;
             width: 100%;
           
             
            }
            label{
                color: green;
                font-size: 20px;
            }
            table{
                padding-bottom:1em;
                width: 500px;
                height: 200px;
            }
			
            .div1 {
    border-radius: 5px;
    background-color: #f2f2f2;
    margin: auto;
   padding: 30px;
    width:50%;
}
input[type=submit] {
    background-color: tomato;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
    width:100px;
}

input[type=submit]:hover {
    background-color: #ac2925;
}


    </style>
    <script src="maha.js"></script>
 </head>
 
 <?php
 if(isset($_POST['id']))
 {
 $a=$_POST['id'];
//echo $a;
$b=$_POST['radio'];
//echo $b;
 
$sql="select * from add_product where prdt_id='$a'";
$tbl=getDatas($sql);
$stock=$tbl[0][4];
$pname=$tbl[0][1];
//echo "f".$stock;
//$quantity=1;
$price=$tbl[0][3];
$img=$tbl[0][6];
$org_id=$tbl[0][8];
     $sql="select cust_id from customer where cust_email='$user'";
     $tbl=getDatas($sql);
     $id1=$tbl[0][0];
     echo $id1;
     date_default_timezone_set('Asia/Calcutta');
$date1 = date("Y-m-d");// current date
$d = date("Y-m-d");
		$s=strtotime("+10 day");
       $k=date("Y-m-d", $s);
$balstock=$stock-1;
$sql="select ifnull(max(order_id),0)+1 from tbl_order";
	$tbl=getDatas($sql);
	$oid=$tbl[0][0];
	//echo "orderid------".$oid;
if($stock<=0){
					echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>Sorry No Stock available...</font></div>";
		}
		else
		{
		
		$sql="update add_product set qty='$balstock' where prdt_id='$a'";
		setDatas($sql);
	

if($b=="credit"){
	?>
<h3 style="position:relative;left:620px;top:130px;">CARD Info.  </h3>
    	<div class="div1"  style="position:relative;top:150px;">
        <form action="card.php" method="post">
           
            <table style="position: relative;left:10px;top:10px">
                <tr>
                    <td>
                        <label>  Card Number</label>
                    </td>
                    <td>
                        <input type="text" name="cno" required />
						<input type="text" name="id" value="<?php echo $a;?>" hidden required />
                      </td>
                </tr>
                      
		   </td></tr>
                 
                   <tr>
                    <td>
                        <label> Password</label>
                    </td>
                    <td>
                        <input type="password" name="pass" required onkeypress="return verifyText(event,'err')" />
                      </td>
                </tr>
           <tr><td></td></tr>                    
				<tr><td></td><td><input type="submit" value="verify"/></td></tr>
            </table>
            
            
        </form></div>

 
<?php
}
 else{
	 
	$sql="insert into tbl_order values('$oid','$a','$user','$pname','$price','$date1','$d','$k','cod','processing','$img','$org_id')";
	       setDatas($sql);
	
     echo "
		    <div style='position:relative;left:450px;top:120px;'>
			<font color='red'>Buyer Name:</font>$user<br>
			<font color='red'>Product:</font>$pname<br>
			
			<font color='red'>Price:</font>$price<br>
			<font color='red'>Expected Delivery:</font>$k<br>
			<font color='red'>Order Date:</font>$d<br>
			we will get back to you shortly!!!!! Thank You.
			</div>
		";
	
 }
 
 }
 }

?>













