<?php 
 session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>
<html>
<head>
<title>feedback</title>
<style>
input,textarea,select,.ab{
                border: 2px solid;
             border-radius: 7px;
             
           
             
            }
            label{
                color: green;
                font-size: 20px;
            }
            table{
                padding-bottom:1em;
                width: 500px;
                height: 500px;
            }
            .div1 {
    border-radius: 5px;
    background-color: #f2f2f2;
    margin: auto;
   padding: 30px;
    width:50%;
}

input[type=submit],.ab {
    margin: auto;
    padding: 10px 25px;
    margin-top: 25px;
    background-color: #146eb4;
    color: white;
border:none;
outline:none;
    letter-spacing: 1px;
    outline: 0;
    cursor: pointer;
}
.heading h1 {
    font-weight: 600;
    letter-spacing: .5px;
    font-size: 40px;
    margin-bottom: .9em;
    text-align: center;
    color: #ff9900;
    text-transform: uppercase;
    position: relative;
    margin-top: 0;
}
input[type=submit]:hover,
{
background-color: #ff9900;
    color: white;
}
.card{
 
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.9);
  width:700px;
    height:800px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.heading h1 {
    font-weight: 600;
    letter-spacing: .5px;
    font-size: 40px;
    margin-bottom: .9em;
    text-align: center;
    color: #ff9900;
    text-transform: uppercase;
    position: relative;
    margin-top: 0;
    }

    body{
        background-image: url("FEED.jpg") ;
        background-size: 1400px;
        background-repeat: no-repeat;
        
    }

</style>
</head>
<?php
$sql="select ifnull(max(feed_id),0)+1 from feedback";
$tbl=getDatas($sql);
   
        

?>
<body>
<br><br>
    <div class="card">
    <!--<div class="heading">
        <h1>FEEDBACK</h1></div> -->
    <br><br>
<form action="" method="post">
<table style="position:relative top:900px; left:100px;">
<BR>
 <BR>
     <BR>
         <BR>
<tr>
<td><label><B>CUSTOMER EMAIL:</B></label></td>
<TD><INPUT TYPE="TEXT" NAME="email1" value="<?php echo $user;?>"></TD>
   

</tr>
<tr>
<td><label><B>ENTER THE FEEDBACK:</B></label></td>
<td><textarea rows=""cols="" name="feedback"></textarea></td>
</tr>

<TR>
	<TD>
	&nbsp&nbsp&nbsp&nbsp&nbsp<BR><BR><INPUT TYPE="SUBMIT" NAME="submit" VALUE="SUBMIT"/>
        </td>
	<td>
    &nbsp&nbsp&nbsp&nbsp&nbsp<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"/></TD>
</TR>
</table></form>
        </CENTER>
    </div>
</body></html>
    <?php
if(isset($_POST['feedback']))
{
$a=$tbl[0][0];
$b=$_POST['email1'];
date_default_timezone_set('Asia/Calcutta');
$date1=date("m/d/y");// current date
$c=$_POST['feedback'];

    $sql="insert into feedback values('$a','$b','$c','$date1')";
setDatas($sql);
    msgbox('Successfully send');
}
    ?>
    