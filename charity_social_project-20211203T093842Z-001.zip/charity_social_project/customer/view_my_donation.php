<?php
session_start();
$user=$_SESSION['userid'];
include_once("../shares/db/mydatabase.inc");
include("top.php"); ?>

<html>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>



<?php

 $sql="select payment_donation.*,req_fund.* from payment_donation JOIN req_fund ON payment_donation.fund_id=req_fund.fund_id where payment_donation.cust_email='$user'";



	$tbl=getDatas($sql);
					if($tbl==null){
						echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>No Donations Yet...</font></div>";

					}
					else
					{

?>

	<!--user--->

	<div class="checkout-right">
					<h1 style="position:relative;left:520px;top:100px;">MY DONATIONS</h1>
				<table border="1" style="position:relative;width:900px;left:150px;top:150px">
					<thead>
						<tr>
							<th>Customer Email</th>
							<th>Organisation Name</th>
							<th>Organisation Email</th>
                            <th>Amount Donated</th>
                            <th>Account Number</th>
                            <th>IFSC Code</th>
                            <th>Category</th>
                            <th>Phone Number</th>
                            <th>Date</th>
							
							
							
							
						</tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr class="rem1">
						
                        
                        <td class="invert"><?php echo $user;?></td>
                        <td class="invert"><?php echo $tbl[$i][7];?></td>
                        <td class="invert"><?php echo $tbl[$i][6];?></td>
						<td class="invert"><?php echo $tbl[$i][3];?></td>
                        <td class="invert"><?php echo $tbl[$i][10];?></td>
                        <td class="invert"><?php echo $tbl[$i][11];?></td>
                        <td class="invert"><?php echo $tbl[$i][14];?></td>
                        <td class="invert"><?php echo $tbl[$i][13];?></td>
                        <td class="invert"><?php echo $tbl[$i][4];?></td>
						
					<?php 
					}
                    }
					?>
					</tbody>
				
				</table>
			</div>
	<!--user-->
        
     </html>
        
            
        
        