<?php
session_start();
$user=$_SESSION['userid'];
include("../shares/db/mydatabase.inc");
 include("top.php");
?>
<head>
<style>
       
input,textarea,select{
                border: 2px solid;
             border-radius: 4px;
             width: 100%;
           
             
            }
            label{
                color: green;
                font-size: 20px;
            }
            table{
                padding-bottom:1em;
                width: 500px;
                height: 200px;
            }
            .div1 {
    border-radius: 5px;
    background-color: #f2f2f2;
    margin: auto;
   padding: 30px;
    width:50%;
}
input[type=submit] {
    background-color: tomato;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
    width:100px;
}

input[type=submit]:hover {
    background-color: #ac2925;
}
</style>
</head>
<div style="position:relative;top:100px;">

<?php
$sql="select * from customer where cust_email='$user'";
$tbl=getDatas($sql);

?>

<div class="w3_login">
     <center>
    <h3><font color="red">My Profile</font> </h3>
      
        <form action="" method="post" >
          
            <table cellspacing="5" cellpadding="5" style="position:relative;top:50px;"> 
                <tr>
                    <td>
                        <label><i> Name:</i></label>
                    </td>
                    <td>
                        <?php echo $tbl[0][1];?>
                      </td>
                </tr>
           <tr><td></td></tr>                       
                 
                
               <tr>
                    <td>
                        <label> <i>Gender:</i></label>
                    </td>
                    <td>
                          <?php echo $tbl[0][2];?>
                      </td>
                </tr>
               
                <tr><td></td><td></td></tr>
                 <tr>
                    <td>
                        <label><i>Phone Number:</i></label>
                    </td>
                    <td>
                          <?php echo $tbl[0][8];?>
                      </td>
                </tr> <tr><td></td></tr>
        <tr>
                    <td>
                        <label><i> Email:</i></label>
                    </td>
                    <td>
                          <?php echo $tbl[0][7];?>
                      </td>
                </tr>
               
                <tr><td></td><td></td></tr>
                 <tr>
                    <td>
                        <label><i> City:</i></label>
                    </td>
                    <td>
                          <?php echo $tbl[0][4];?>
                      </td>
                </tr>
                <tr><td></td><td></td></tr>
                 
        <tr><td></td><td>
                
                   </td></tr>
               <tr><td></td><td></td></tr>
                <tr><td>
                        <div class="w3l_header_right1">
      &emsp;&emsp;&emsp;&emsp;<h2><a href="edit.php"><font size="5px"  color="red">EDIT</font></a></h2>
    </div></td></tr>
            </table>    
        </form>
           </center>
                                   </div>
        <div class="clearfix"></div>
    
