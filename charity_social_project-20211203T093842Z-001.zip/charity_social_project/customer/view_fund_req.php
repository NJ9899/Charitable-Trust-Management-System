<?php

include_once("../shares/db/mydatabase.inc");?>
 <?php include("top.php"); ?>
 <head>
<style>
 table{
                   border: 2px solid #111;
                   border-radius: 1em;
                   width: 80%;
                   margin-left:0px;
                   
               }
               th {
    background-color: #17c3a2;
    color: white;
    height: 40px;
}
tr{
    height: 30px;
    border-bottom: 1px solid #ddd;
}

    </style>
 </head>



<?php
if(isset($_GET['id']))
{

 $m=$_GET['id'];
 //echo $m;
 	$sql="select * from req_fund where org_mail='$m' and status='active'";


	$tbl=getDatas($sql);
					if($tbl==null){
						echo "<div style='position:relative;top:250px;left:620px;'><font color='red'>No Requests...</font></div>";

					}
					else
					{

?>

	<!--user--->

	<div class="checkout-right">
					<h1 style="position:relative;left:520px;top:100px;">FUND REQUEST VIEW</h1>
				<table border="1" style="position:relative;width:900px;left:150px;top:150px">
					<thead>
						<tr>
							<th>Organisation Name</th>
							<th>Amount</th>
                            <th>Purpose</th>
                            <th>Account Number</th>
                            <th>IFSC Code</th>
                            <th>Target Date</th>
                            <th>Phone No</th>
                            <th>Payment</th>
							
							
							
							
						</tr>
					</thead>
					<?php
					
					for($i=0;$i<count($tbl);$i++)
					{
						for($j=0;$j<count($tbl[$i]);$j++)
						{
						}
					?>
					<tbody><tr class="rem1">
						
                        
                        <td class="invert"><?php echo $tbl[$i][2];?></td>
                        <td class="invert"><?php echo $tbl[$i][3];?></td>
						<td class="invert"><?php echo $tbl[$i][4];?></td>
						<td class="invert"><?php echo $tbl[$i][5];?></td>
						<td class="invert"><?php echo $tbl[$i][6];?></td>
						<td class="invert"><?php echo $tbl[$i][7];?></td>
                        <td class="invert"><?php echo $tbl[$i][8];?></td>
                        <td><a href="payment.php?id=<?php echo $tbl[$i][0];?>">Payment here!!!</a></td>
						
					
						
					<?php 
					}
                    }
					}
					?>
					</tbody>
				
				</table>
			</div>
	<!--user-->
        
     
        
            
        
        