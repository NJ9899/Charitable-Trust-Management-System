<?php include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>

<HTML>
<HEAD><TITLE>ADD ORGANISATION</TITLE>
<STYLE>
LABEL
{
	COLOR:red;
	FONT-SIZE:100%;
}
INPUT[TYPE=TEXT],[TYPE=DATE],[TYPE=EMAIL],[TYPE=PASSWORD],SELECT,TEXTAREA
{
	BORDER-RADIUS:4PX;
	height:40px;
	width:300px;
   
}

INPUT[TYPE=SUBMIT],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	border-radius:30px;
	height:30px;
	width:80px;
	font-weight:bold;
	margin-right:20px;
	margin-top:0px;
	position:relative;
	left:200px;
}
    input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red;
}
table
{
	height:700px;
}
H1
{
	color:black;
	text-align:center;
	FONT-SIZE:200%;
	position:relative;
	left:100px;
}
tr
{
	HEIGHT:50PX;
    
}
.CONTAINER
{

	BACKGROUND-COLOR:WHITE;
	HEIGHT:590;
   
}
    .s1{
        position: absolute;
right: 150px;
    top: 600px;
        transform: translate(-50%,-50%);
        width: 600px;
        height: 800px;
    border-radius:10px;
        box-sizing: border-box;
        background: #01a2a6;
       color:white; 
    }
	</STYLE>
    <script src="maha.js"></script>
</HEAD>
 
    
<!-- back button disable -->           
<script type="text/javascript">
       history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});
    </script>
 <!-- //back button disable -->     
    
    

<BODY>
 
<div CLASS="CONTAINER">
    <center>
<H1>ORGANISATION REGISTRATION</H1>
    <div id="err" style="color: red;height: 20px"></div>
<FORM action="" method="post">
<TABLE STYLE="POSITION:RELATIVE;LEFT:50PX;TOP:25PX">

<tr>
	<td><LABEL><B>ORGANISATION NAME:</B></LABEL></td>
	<td><INPUT TYPE="TEXT" NAME="oname" onkeypress="return verifyText(event,'err')" REQUIRED=" "/></td>
</tr>
<tr>
    <td><LABEL><B>CATEGORY:</B></LABEL></td>
    <td><select name="category">
        <option>--Select category--</option>
        <option value="orphanage">ORPHANAGE</option>
        <option value="womenwelfare">WOMEN'S WELFARE</option>
        <option value="oldagehome">OLD AGE HOME</option>
        </select>
    </td>
</tr>
<tr>
	<td><LABEL><B>CITY:</B></LABEL></td>
	<td><input type="text" NAME="city" onkeypress="return verifyText(event,'err')" REQUIRED></td>
</tr>
<tr>
	<td><LABEL><B>DISTRICT:</B></LABEL></td>
	<td><input type="text" NAME="district" onkeypress="return verifyText(event,'err')" REQUIRED></td>
</tr>
<tr>
	<td><LABEL><B>PINCODE:</B></LABEL></td>
	<td><input type="text" NAME="pin" REQUIRED></td>
</tr>

<tr>	
	<td><LABEL><B>LICENSE PROOF:</B></LABEL></td>
	<td><INPUT type="FILE" NAME="reg" REQUIRED/></td>
</tr>
<tr>
	<td><LABEL><B>ORGANIZATION EMAIL:</B></LABEL></td>
	<td><input type="text" NAME="email" REQUIRED></td>
</tr>
<tr>
	<td><LABEL><B>PHONE NO:</B></LABEL></td>
	<td><INPUT TYPE="TEXT" NAME="ophno" onkeypress="return verifyPhone(this,event,'err')" onblur="return varifyLength(this,'err',10,10);" REQUIRED/></td>
</tr>
<tr>
	<td><LABEL><B>PERSON OF CONTACT</B></LABEL></td>
	<td><input type="text" NAME="poc" onkeypress="return verifyText(event,'err')" REQUIRED></td>
</tr>
<tr>
	<td><LABEL><B>PERSON OF CONTACT PHONE NO:</B></LABEL></td>
	<td><input type="text" NAME="pocno" pattern="^\d{4}\d{3}\d{3}$" title="must contain 10 numbers" REQUIRED></td>
</tr>
<tr>
	<td><LABEL><B>PASSWORD:</B></LABEL></td>
	<td><input type="password" name="opass"   onclick="a()" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required ><span id="txt1"></span></td>
</tr>
<tr>
<td>
<label>CONFIRM PASSWORD:</label></td> 
<td><input type="password" name="cpwd" required="" title="Should be same as password" required=""></td></tr>
    

<center><tr>
	<td>
	<INPUT TYPE="SUBMIT" NAME="submit2" VALUE="ADD"/>
	</td>
    <td>
	<INPUT TYPE="reset" NAME="reset" VALUE="CANCEL"/>
	</td>    
        </tr>
</center>

</TABLE>
</FORM>
</center>

</div>
       
    
</BODY>
</HTML>
<?php
if(isset($_POST['oname']))
{

$b=$_POST['oname'];

$c=$_POST['category'];
$d=$_POST['city'];
$e=$_POST['district'];
$f=$_POST['pin'];
$g=$_POST['reg'];
$h=$_POST['email'];
$i=$_POST['ophno'];
$j=$_POST['poc'];
$k=$_POST['pocno'];
$l=$_POST['opass'];
$m=$_POST['cpwd'];
    
$sql="select org_mail from organisaion where org_mail='$h'";
$tbl=getDatas($sql);
    $eml=$tbl[0][0];

if($l!=$m)
{
        msgbox('Password missmatch');
}

elseif($eml<0)
{ 
$sql="select ifnull(max(org_id),0)+1 from organisation";
$tbl=getDatas($sql);
    

$sql="insert into organisation values('$tbl[0][0]','$b','$c','$d','$e','$f','$g','$h','$i','$j','$k')";
setDatas($sql);
$sql="insert into login values('$h','$l','$c','0')";
setDatas($sql);
msgbox('Successfully registerd');
    nextpage('login.php');
}


    else
        msgbox('This email id already exists');  

    
}

?>



	