<?php include_once("../shares/db/mydatabase.inc"); ?>
<?php include("top.php");?>

<html>
<head>
<title>add_customer</title>
<style>
input[type=date],input[type=text],input[type=email],input[type=password],textarea,select
{
	
	border-radius:4px;
	width:300px;
	height:40px;
}
input[type=radio]
    {
       width:30px;
	   height:10px; 
    }
label
{
	color:red;
}
input[type=submit],input[type=reset]
{
	background-color:tomato;
	color:white;
	border:none;
	border-radius:30px;
	height:30px;
	width:80px;
	font-weight:bold;
	margin-right:20px;
	margin-top:20px;
	position:relative;
	left:200px;
}
    .s1{
        position: absolute;
right: 150px;
    top: 600px;
        transform: translate(-50%,-50%);
        width: 600px;
        height: 800px;
    border-radius:10px;
        box-sizing: border-box;
        background: #01a2a6;
       color:white; 
    }
input[type=submit]:hover,input[type=reset]:hover
{
	background-color:red;
}
table
{
	height:700px;
}
</style>
    <script src="maha.js"></script>

</head>
    

<!-- back button disable -->           
<script type="text/javascript">
       history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});
    </script>
 <!-- //back button disable --> 


<body>
     
 <!-- <div class="s1"> -->
         
<center>
<h1>CUSTOMER REGISTRATION</h1>
    <div id="err" style="color: red;height: 20px"></div>
    <br>
    <br>
<form action="" method="post">

<table>
    

<tr>
<td>
<label>NAME:</label></td> 
<td><input type="text" name="cname1" onkeypress="return verifyText(event,'err')" required></td></tr>
<tr>
<tr>
<td>
<label>GENDER:</label></td> 
<td><input type="radio" name="gender" value="male" checked>Male
    <input type="radio" name="gender" value="female" >Female</td></tr>
<tr>
<td>
<label>HOUSENO:</label></td>
<td><input type="text" name="hno" required> 
</td></tr>
<tr>
<td>
<label>CITY:</label></td>
<td><input type="text" name="city" onkeypress="return verifyText(event,'err')" required></td></tr>
<tr>
<td>
<label>DISTRICT:</label></td>
<td><input type="text" name="dis" onkeypress="return verifyText(event,'err')" required></td></tr>
<tr>
<td>
<label>PINCODE:</label></td>
<td><input type="text" name="pin"></td></tr>
<tr>
<td>
<label>EMAIL:</label></td>
<td><input type="email" name="email1"></td>
</tr>    
<tr>
<td>
<label>PHONE NUMBER:</label></td> 
<td><input type="text" name="num1"  pattern="^\d{4}\d{3}\d{3}$" title="must contain 10 numbers" required ></td></tr>

<tr>
<td>
<label>PASSWORD:</label></td> 
<td><input type="password" name="password" class="abcd"  onclick="a()" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required ><span id="txt1"></span></td></tr>
    
<tr>
<td>
<label>CONFIRM PASSWORD:</label></td> 
<td><input type="password" name="cpwd" required="" title="Should be same as password" required="" ></td></tr>
    

<center><tr>
<td>
<input type="submit" name="submit1" value="ADD">
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<INPUT TYPE="RESET" NAME="cancel" VALUE="CANCEL"></td></tr></center>
</table>
</form>
</center>
    <!--</div> -->
   
</body></html>
<?php
if(isset($_POST['cname1']))
{
//$a=$_POST['id'];

$b=$_POST['cname1'];

$i=$_POST['gender'];
$c=$_POST['hno'];
$d=$_POST['city'];
$e=$_POST['dis'];
$f=$_POST['password'];
$g=$_POST['cpwd'];
$h=$_POST['email1'];
$k=$_POST['num1'];
    $r=$_POST['pin'];
    
$sql="select * from customer where cust_email='$h'";
    $tbl=getDatas($sql);
    $eml=$tbl[0][0];
if($f!=$g)
{
    msgbox('password missmatch');

}
elseif($eml<0)
    {
    $sql="select ifnull(max(cust_id),0)+1 from customer";
$tbl=getDatas($sql);
    
  $sql="insert into customer values('$tbl[0][0]','$b','$i','$c','$d','$e','$r','$h','$k')";
setDatas($sql);
$sql="insert into login values('$h','$f','customer','1')";
		setDatas($sql);
		msgbox('Successfully registerd');
    nextpage('login.php');
}
        
else
    msgbox('This email id already exists');
}

?>
