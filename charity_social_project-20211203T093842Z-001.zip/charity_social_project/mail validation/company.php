<?php include("top.php");?>

<?php 
include("../shares/db/mydatabase.inc"); 
?>

<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!doctype html>
<html>

<head>
	<title>Company registration</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Student Registration Form Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- fonts -->
	<link href="../Student_reg_temp/web/fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
	<!-- /fonts -->
	<!-- css -->
	<link href="../Student_reg_temp/web/css/bootstrap.css" rel="stylesheet" type='text/css' media="all" />
	<link href="../Student_reg_temp/web/css/style.css" rel="stylesheet" type='text/css' media="all" />
	<!-- /css -->
	<script src="..//Common/maha.js"></script>
</head>

<body>

	<div class="content-agileits">
		<h1 class="title">COMPANY REGISTRATION FORM</h1>
		<div id="err" style="color: red;height: 20px"></div>
		<div class="left">
			<form action="" method="post" data-toggle="validator" enctype="multipart/form-data">
				<div class="form-group">
					<label for="firstname" class="control-label">Company Name:</label>
					<input type="text" name="companyname" class="form-control" id="firstname" onkeypress="return verifyText(event,'err')" placeholder="Company Name" data-error="Enter Your Company Name" title="Must contain text values only" pattern="[A-Za-z]{1,15}" required >
					<div class="help-block with-errors"></div>
				</div>
                <div class="form-group">
					<label for="house" class="control-label">Licence Number:</label>
					<input type="text" class="form-control" name="license" id="firstname" placeholder="Licence Number" data-error="Enter Your License Number" required >
					<div class="help-block with-errors"></div>
				</div>
                <div class="form-group">
					<label for="district" class="control-label">District:</label>
					<input type="text" class="form-control" name="district" id="firstname" onkeypress="return verifyText(event,'err')" placeholder="District" data-error="Enter Your District" required >
					<div class="help-block with-errors"></div>
				</div>
                <div class="form-group">
					<label for="city" class="control-label">City:</label>
					<input type="text" class="form-control" name="city" id="firstname" onkeypress="return verifyText(event,'err')" placeholder="City" data-error="Enter Your City" required >
					<div class="help-block with-errors"></div>
				</div>
                
                <div class="form-group">
					<label for="pincode" class="control-label">Pincode:</label>
					<input type="text" class="form-control" name="pincode" id="firstname" placeholder="Pincode" data-error="Enter Your Pincode" required >
					<div class="help-block with-errors"></div>
				</div>
                <div class="form-group">
					<label for="pincode" class="control-label">Mobile number:</label>
					<input type="text" class="form-control" name="mobile" id="firstname" placeholder="Mobile Number" data-error="Enter Your Mobile Number" required  onkeypress="return verifyPhone(this,event,'err')" onblur="return varifyLength(this,'err',10,10);" >
					<div class="help-block with-errors"></div>
				</div>
                
                
                <div class="form-group">
					<label for="inputEmail" class="control-label">Email:</label>
					<input type="email" class="form-control" name="email" id="inputEmail" placeholder="Email" data-error="This email address is invalid" required>
					<div class="help-block with-errors"></div>
				</div>
                 <div class="form-group">
					<label for="pincode" class="control-label">Photo:</label>
					<input type="file" class="form-control" name="file"  data-error="Enter Your Mobile Number" required >
					<div class="help-block with-errors"></div>
				</div>
                
                
				<div class="form-group">
					<label for="inputPassword" class="control-label">Password:</label>
					<div class="form-inline row">
						<div class="form-group col-sm-6 agileits-w3layouts">
							<input type="password" data-minlength="6" class="form-control" name="password" id="inputPassword" placeholder="Password" required >
							<div class="help-block"></div>
						</div>
						<div class="form-group col-sm-6 w3-agile">
							<input type="password" class="form-control" name="password1" id="inputPasswordConfirm" data-match="#inputPassword" data-match-error="Whoops, these don't match"
							    placeholder="Confirm Password" required>
							<div class="help-block with-errors"></div>
						</div>
					</div>
				</div>
				
				
				<div class="form-group">
					<button type="submit" class="btn btn-lg">submit</button>
				</div>
			</form>
		</div>
		<div class="right"></div>
		<div class="clear"></div>
	</div>
	<!-- js -->
	<script src="../Student_reg_temp/web/js/jquery-2.1.4.min.js"></script>
	<!-- //js -->

	<script src="../Student_reg_temp/web/js/bootstrap.min.js"></script>
	<script src="../Student_reg_temp/web/js/validator.min.js"></script>
	<!-- /js files -->
</body>

</html>

<?php

	

$fldr = "../uploads";
	$allowedExts = array("jpg", "gif", "jpeg","mp4");
	$extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
	$f=$_FILES["file"]["name"];
	
	//echo "upload/$f";

	
	$size = $_FILES["file"]["size"];
	if($_FILES["file"]["size"] > 5000000)
	{
		die("File Size is ".($size/1000000)."MB, Maximum allowed size is 5MB");
	}
	if ((($_FILES["file"]["type"] == "image/jpg")
	|| ($_FILES["file"]["type"] == "image/jpeg")
	|| ($_FILES["file"]["type"] == "image/gif")
	|| ($_FILES["file"]["type"] == "video/mp4"))
	
	&& ($_FILES["file"]["size"] <= 50000000)
	&& in_array($extension, $allowedExts))
	{
		if ($_FILES["file"]["error"] > 0)
		{
			echo "Return Code: " .$_FILES["file"]["error"]. "<br />";
		}
		else
		{
		if (file_exists("$fldr/" .$_FILES["file"]["name"]))
		{
			echo $_FILES["file"]["name"] . " already exists. ";
		}
		else
		{
			move_uploaded_file($_FILES["file"]["tmp_name"],"$fldr/" . $_FILES["file"]["name"]);
			

			$mv_name = $_FILES["file"]["name"];		
			$mv_type = $_FILES["file"]["type"];
				$fname=$fldr."/".$mv_name;
			$mv_size = $_FILES["file"]["size"];
			
if(isset($_POST['companyname']))
{
$b=$_POST['companyname'];
$c=$_POST['license'];
$d=$_POST['district'];
$e=$_POST['city'];
$f=$_POST['pincode'];
$g=$_POST['mobile'];
$h=$_POST['email'];
$i=$_POST['password'];
$j=$_POST['password1'];
$k=$_POST['file'];
	

	
	
$sql="select * from company_reg where email='$h'";
$tbl=getDatas($sql);
$eml=$tbl[0][0];

	if($i!=$j)
{
     msgbox("password missmatch");
}
elseif($eml>0)
{
	msgbox('email already exist');
}
else
{
$sql="select ifnull(max(company_id),0)+1 from company_reg";
$tbl=getDatas($sql);

    $sql="insert into company_reg values('$tbl[0][0]','$b','$c','$d','$e','$f','$g','$h','$fname')";
setDatas($sql);
$sql="insert into login values('$h','$i','company','0')";
		setDatas($sql);
		msgbox('Successfully registered');
	 nextpage('login.php');
}
}
        }
        }
    }

?>















